import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';

interface ShutterLookupResponse {
  data: {
    Shuttered: boolean;
  };
}

interface ShutterLookupConfig {
  featureID: string;
  featureType: string;
  dataViewName: string;
}

export async function fetchShutterStatus({ featureID, featureType, dataViewName }: ShutterLookupConfig): Promise<boolean> {
  const sdkConfig = await getSdkConfig();

  const url = new URL(
    `${sdkConfig.serverConfig.infinityRestServerUrl}/app/${sdkConfig.serverConfig.appAlias}/api/application/v2/data_views/${dataViewName}`
  ).href;

  const parameters = new URLSearchParams(`{FeatureID: ${featureID}, FeatureType: ${featureType}}`);

  try {
    const response = (await PCore.getRestClient().invokeCustomRestApi(
      `${url}?dataViewParameters=${parameters}`,
      {
        method: 'GET',
        body: {},
        headers: {},
        withoutDefaultHeaders: false
      },
      ''
    )) as ShutterLookupResponse;

    return response.data.Shuttered;
  } catch {
    return false;
  }
}
