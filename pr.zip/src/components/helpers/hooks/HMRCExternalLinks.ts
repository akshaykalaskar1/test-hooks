import { useEffect, useState } from 'react';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';

export default function useHMRCExternalLinks() {
  const [referrerURL, setReferrerURL] = useState<string>(null);
  const [hmrcURL, setHmrcURL] = useState<string>(null);
  const [hmrcQAURL, setHmrcQAURL] = useState<string>(null);
  useEffect(() => {
    const getReferrerURL = async () => {
      const {
        serverConfig: { sdkContentServerUrl, sdkHmrcURL, sdkHmrcQAURL }
      } = await getSdkConfig();
      setReferrerURL(sdkContentServerUrl);
      setHmrcURL(sdkHmrcURL);
      setHmrcQAURL(sdkHmrcQAURL);
    };
    getReferrerURL();
  }, []);

  return { referrerURL, hmrcURL, hmrcQAURL };
}
