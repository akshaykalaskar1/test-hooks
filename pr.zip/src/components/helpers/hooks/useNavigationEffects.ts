import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { scrollToTop } from '../utils';
import { staySignedIn } from '../../AppComponents/TimeoutPopup/timeOutUtils';

const useNavigationEffects = (
  setShowTimeoutModal: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const location = useLocation();

  useEffect(() => {
    staySignedIn(setShowTimeoutModal, true);
    scrollToTop();
  }, [location.pathname]);
};

export default useNavigationEffects;
