import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

type NavigateOptions = {
  replace?: boolean;
};

const useCustomNavigate = () => {
  const navigate = useNavigate();

  const goTo = useCallback(
    (path: string, state?: Record<string, unknown>, options?: NavigateOptions) => {
      navigate(path, {
        state,
        replace: options?.replace
      });
    },
    [navigate]
  );

  return goTo;
};

export default useCustomNavigate;
