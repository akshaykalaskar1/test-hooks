import React, { ElementType } from 'react';
import PropTypes from 'prop-types';

export interface LoadingSpinnerProps {
  size?: string;
  topTag?: ElementType;
  bottomTag?: ElementType;
  topText?: string;
  label?: string;
  bottomText?: string;
  borderColor?: string;
  topBorderColor?: string;
}

const LoadingSpinner = ({
  size,
  topText,
  bottomText,
  topTag,
  bottomTag,
  borderColor,
  topBorderColor
}: LoadingSpinnerProps) => {
  const TopHeaderTag = topTag || 'h1';
  const BottomTextTag = bottomTag || 'h1';
  const BorderColor = borderColor || '#dee0e2';
  const TopBorderColor = topBorderColor || '#1d70b8';

  return (
    <>
      <TopHeaderTag className='govuk-heading-s'>{topText}</TopHeaderTag>
      <div
        className='loading-spinner'
        style={{
          width: size,
          height: size,
          borderColor: BorderColor,
          borderTopColor: TopBorderColor
        }}
        aria-hidden='true'
      >
        <div className='spinner'></div>
      </div>
      <BottomTextTag className='govuk-heading-s'>{bottomText}</BottomTextTag>
    </>
  );
};

LoadingSpinner.propTypes = {
  size: PropTypes.string,
  topTag: PropTypes.string,
  bottomTag: PropTypes.string,
  topText: PropTypes.string,
  label: PropTypes.string,
  bottomText: PropTypes.string,
  borderColor: PropTypes.string,
  topBorderColor: PropTypes.string
};

LoadingSpinner.defaultProps = {
  size: '50px',
  borderColor: '#dee0e2',
  topBorderColor: '#1d70b8'
};

export default LoadingSpinner;
