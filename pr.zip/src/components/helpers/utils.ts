import { getSdkConfig, logout } from '@pega/auth/lib/sdk-auth-manager';
import dayjs from 'dayjs';
import { t } from 'i18next';
import { AllowanceObject, DetailsTypes } from '../../samples/app/iabd/PayeCurrentYear/PayeCurrentYearTypes';
import { validateDate } from 'hmrc-odx-features-and-functions';

declare const PCore: any;

interface ErrorMessage {
  message: {
    fieldId: string;
    message: string;
    pageRef: string;
    clearMessageProperty: string;
  };
}

interface DateOptions {
  minYear?: number;
  invalid?: string;
}

export const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: 'smooth'
  });
  document.body.focus();
};

export const GBdate = (date: string) => {
  const d = String(date).split('-');
  return d.length > 1 ? `${d[2]}/${d[1]}/${d[0]}` : date;
};

export const checkErrorMsgs = (errorMsgs: ErrorMessage[] = [], fieldIdentity = '', fieldElement = '') => {
  return errorMsgs.find((element: ErrorMessage) => element.message.fieldId === fieldIdentity || element.message.fieldId.startsWith(fieldElement));
};

export const shouldRemoveFormTagForReadOnly = (pageName: string) => {
  const arrContainerNamesFormNotRequired = ['Your date of birth'];
  return arrContainerNamesFormNotRequired.includes(pageName);
};

export const isUnAuthJourney = () => {
  const containername = PCore.getContainerUtils().getActiveContainerItemName(`${PCore.getConstants().APP.APP}/primary`);
  const context = PCore.getContainerUtils().getActiveContainerItemName(`${containername}/workarea`);
  const caseType = PCore.getStoreValue('.CaseType', 'caseInfo.content', context);
  return caseType === 'Unauth';
};

export const isSingleEntity = (propReference: string, getPConnect: any) => {
  const containerName = getPConnect().getContainerName();
  const context = PCore.getContainerUtils().getActiveContainerItemContext(`${PCore.getConstants().APP.APP}/${containerName}`);

  const count = PCore.getStoreValue(propReference.split('[')[0], 'caseInfo.content', context)?.length;

  if (typeof count !== 'undefined' && count === 1) return true;
};

export const removeRedundantString = (redundantString: string, separator: string = '.') => {
  const list: string[] = redundantString.split(separator);
  const newList: string[] = [];
  let uniqueString = '';
  if (list.length > 0) {
    list.forEach(item => {
      if (!newList.includes(item.trim())) {
        newList.push(item);
      }
    });
    if (newList.length > 0) {
      newList.forEach(element => {
        uniqueString = uniqueString + (uniqueString.length > 0 ? '. ' : '') + element.trim();
      });
    }
  }
  return uniqueString;
};

export const checkStatus = () => {
  const containername = PCore.getContainerUtils().getActiveContainerItemName(`${PCore.getConstants().APP.APP}/primary`);
  const context = PCore.getContainerUtils().getActiveContainerItemName(`${containername}/workarea`);
  const status = PCore.getStoreValue('.pyStatusWork', 'caseInfo.content', context);
  return status;
};

export const formatDate = (dateString: string) => {
  return dayjs(dateString).format('D MMMM YYYY');
};

// This new code is tempory solution from react, it will be removed in next sprint as this content will come from pega with welsh
export const getTaxCodeForTimeline = (taxCode: string) => {
  const exceptionalTaxCodes = ['BR', 'D0', 'D1', 'SBR', 'SD0', 'SD1', 'SD2', 'SD3', 'CBR', 'CD0', 'CD1', 'NT'];

  if (exceptionalTaxCodes.includes(taxCode?.split(' ')[0])) {
    return t(taxCode?.toUpperCase().replace(' ', '_').replace('WEEK1/MONTH1', 'WEEK1_MONTH1'));
  }
};

export const formatTaxCode = (taxCode: string) => {
  return taxCode?.replace('Week1/Month1', t('WEEK1_MONTH1'));
};

export const handleTranslation = (word: string) => {
  return t(word.toUpperCase());
};

export const generateKey = (name: string, index: number, employer: string = '') => {
  return `${name}_${index}_${employer}`;
};

export const formatCurrency = (amount: string | number | undefined, isTruncate: boolean = false): string => {
  if (typeof amount !== 'string' && typeof amount !== 'number') {
    return '';
  }

  const cleanAmount = amount
    .toString()
    .replace(/[^\d.-]/g, '')
    .trim();

  if (isNaN(Number(cleanAmount))) {
    return '';
  }

  const parsedAmount = Math.floor(Number(cleanAmount) * 100) / 100;

  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: isTruncate ? 0 : 2,
    maximumFractionDigits: isTruncate ? 0 : 2
  })
    .format(parsedAmount)
    .replace('-', '−'); // Use minus sign (U+2212)
};

export const currencyFormatter = (amount: string | number | undefined): string => {
  if (typeof amount !== 'string' && typeof amount !== 'number') {
    return '';
  }

  const str = amount.toString().trim();
  if (!str) return '';

  let result = '';
  let hasDecimal = false;
  let hasMinus = false;

  for (let i = 0; i < str.length; i++) {
    const ch = str[i];

    if (ch === '-' && i === 0) {
      hasMinus = true;
      continue;
    }

    if (ch >= '0' && ch <= '9') {
      result += ch;
      continue;
    }

    if (ch === '.' && !hasDecimal) {
      hasDecimal = true;
      result += '.';
      continue;
    }
  }

  if (!result) return '';

  const [integerPart, initialDecimalPart] = result.split('.');
  let decimalPart = initialDecimalPart ?? '';

  if (decimalPart.length > 2) {
    decimalPart = decimalPart.slice(0, 2);
  }

  let normalized = decimalPart ? `${integerPart}.${decimalPart}` : integerPart;

  if (hasMinus) {
    normalized = '-' + normalized;
  }

  const numericValue = Number(normalized);
  if (isNaN(numericValue)) return '';

  const originalHadDecimal = str.includes('.');

  const formatted = new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: originalHadDecimal ? 2 : 0,
    maximumFractionDigits: originalHadDecimal ? 2 : 0
  }).format(numericValue);

  let finalOutput = formatted;
  if (hasMinus) {
    if (finalOutput.startsWith('-')) {
      finalOutput = '−' + finalOutput.slice(1); // Use minus sign (U+2212)
    }
  }

  return finalOutput;
};

export const getTesLinks = (tesLinkID: string, tesLinks: any[]) => {
  return tesLinks?.filter(tesLink => tesLink.pyKeyString === tesLinkID);
};

export const getTESLinksOnLang = (details: DetailsTypes | AllowanceObject, lang: string) => {
  const TESLinkArr = details?.TESLinks?.map(tesLink => tesLink?.Content.filter(tes => tes?.Language.toLowerCase() === lang)[0]);
  return TESLinkArr;
};

export const getCurrentLang = (): string => {
  const lang = sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';
  return lang;
};

export function getHeadingContent(content, lang) {
  const contentObj = content?.find(obj => obj?.Language.toLowerCase() === lang);
  return contentObj;
}

export function truncate(value: string | number) {
  if (typeof value !== 'string' && typeof value !== 'number') {
    return '';
  }

  if (isNaN(+value) || value === '') {
    return '';
  }
  return Math.trunc(+value);
}

export const triggerLogout = async (isAutoSignout?: boolean) => {
  let authType = 'gg-paye';
  await getSdkConfig().then(sdkConfig => {
    const sdkConfigAuth = sdkConfig.authConfig;
    authType = sdkConfigAuth.authService;
  });
  const authServiceList = {
    'gg-paye': 'GovGateway-PAYE',
    'gg-paye-dev': 'GovGateway-PAYE-dev'
  };

  const authService = authServiceList[authType];

  // If the container / case is opened then close the container on signout to prevent locking.
  const activeCase = PCore.getContainerUtils().getActiveContainerItemContext('app/primary');
  if (activeCase) {
    PCore.getContainerUtils().closeContainerItem(activeCase, { skipDirtyCheck: true });
  }

  type responseType = { URLResourcePath2: string };

  PCore.getDataPageUtils()
    .getPageDataAsync('D_AuthServiceLogout', 'root', {
      AuthService: authService,
      Application: isAutoSignout ? 'PAYE_Timeout' : 'PAYE'
    })
    .then((response: unknown) => {
      const logoutUrl = (response as responseType).URLResourcePath2;

      logout().then(() => {
        if (logoutUrl) {
          // Clear previous sessioStorage values
          sessionStorage.clear();
          window.location.href = logoutUrl;
        }
      });
    });
};
export function getTransactionID(num: number): string {
  return `Paye_${num}`;
}

export function formatValidatedDate(value: string, t: (key: string) => string, options: DateOptions = {}): string {
  const invalid = options.invalid ?? t('DATE_NOT_AVAILABLE');

  const validated = validateDate(value, {
    minYear: options.minYear ?? 1900,
    invalidDateValue: invalid
  });

  const date = new Date(validated);
  if (validated === invalid || isNaN(date.getTime())) {
    return invalid;
  }

  return formatDate(validated);
}

export async function fetchDataAndError() {
  try {
    const empData = await PCore.getDataPageUtils().getPageDataAsync('D_PAYEDetails', 'root');

    if (empData) {
      const { Customer, pyURLContent, pyErrors } = empData;
      const ErrorMsg = pyErrors && pyErrors.pyMessages[0];
      return { Customer, MDTPURLVALUE: pyURLContent, pyErrors: ErrorMsg };
    } else {
      throw new Error('Empty response received');
    }
  } catch (error) {
    console.error('Error fetching employment tax data:', error);
    return { Customer: null, MDTPURLVALUE: null, pyErrors: null };
  }
}

export const appendLangParam = (url: string): string => {
  if (!url) return url;

  const lang = getCurrentLang();
  const [urlWithoutHash, hash] = url.split('#');
  const [path, query] = urlWithoutHash.split('?');

  if (query) {
    const params = query.split('&');
    const hasLang = params.some(param => param.startsWith('lang='));
    if (hasLang) return url;

    const appendLang = `${path}?${query}&lang=${lang}`;
    return hash ? `${appendLang}#${hash}` : appendLang;
  }

  const appendLang = `${path}?lang=${lang}`;
  return hash ? `${appendLang}#${hash}` : appendLang;
};

export async function fetchPAYELanding() {
  try {
    const res = await PCore.getDataPageUtils().getPageDataAsync('D_PAYELanding', 'root');
    return res;
  } catch (error) {
    console.error('Error fetching annual code data:', error);
    return null;
  }
}

export async function fetchAnnualCoding() {
  try {
    const res = await PCore.getDataPageUtils().getPageDataAsync('D_AnnualCoding', 'root');
    return res;
  } catch (error) {
    console.error('Error fetching annual code data:', error);
    return null;
  }
}

export function focusOnElement(event: React.MouseEvent<HTMLAnchorElement>, selector: string) {
  event.preventDefault();

  const element = document.querySelector(selector);

  if (element instanceof HTMLElement) {
    element.setAttribute('tabindex', '-1');
    element.focus();
  }
}

export const filterList = (list: any[] = []) =>
  list.map(item => ({
    AssignedTaxCode: item.AssignedTaxCode,
    EmployerName: item.EmployerName,
    EstimatedPay: item.EstimatedPay,
    PAYENumber: item.PAYENumber,
    PayRollID: item.PayRollID,
    StartDate: item.StartDate
  }));

export const createCase = async ({ caseId, startingFields }: { caseId: string; startingFields?: any }) => {
  await PCore.getMashupApi().createCase(caseId, PCore.getConstants().APP.APP, { startingFields });
};
