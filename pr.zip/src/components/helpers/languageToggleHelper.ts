import { i18n } from 'i18next';
import setPageTitle from './setPageTitleHelpers';
import dayjs from 'dayjs';

const languageToggle = async (lang: string, i18nRef: i18n) => {
  sessionStorage.setItem('rsdk_locale', `${lang}_GB`);
  dayjs.locale(lang);
  i18nRef.changeLanguage(lang).then(() => {
    setPageTitle();
  });

  if (typeof PCore !== 'undefined') {
    const { GENERIC_BUNDLE_KEY } = PCore.getLocaleUtils();

    // common bundles for all applications
    const commonBundles = [GENERIC_BUNDLE_KEY, '@BASECLASS!DATAPAGE!D_NATIONALITYLIST', '@BASECLASS!DATAPAGE!D_COUNTRYLISTSORTEDBYCOUNTRY'];

    const resourceBundles = [...commonBundles];

    PCore.getEnvironmentInfo().setLocale(`${lang}_GB`);
    PCore.getLocaleUtils().resetLocaleStore();
    await PCore.getLocaleUtils().loadLocaleResources(resourceBundles);
  }
};

// Bundles  for IABD
const loadBundles = async (lang: string) => {
  if (typeof PCore !== 'undefined') {
    PCore.getEnvironmentInfo().setLocale(lang);
    await PCore.getLocaleUtils().loadLocaleResources(['en-GB', 'cy-GB']);
  }
};

export default languageToggle;
export { loadBundles };
