import { withKnobs } from '@storybook/addon-knobs';

import HmrcOdxCheckAnswers from './index';
import { DateInput, Input, FieldValueList, Text } from '@pega/cosmos-react-core';
import { PhoneInput as CosmosPhone } from '@pega/cosmos-react-core';
import { pyReviewRaw, regionChildrenResolved } from './mock';

export default {
  title: 'HmrcOdxCheckAnswers',
  decorators: [withKnobs],
  component: HmrcOdxCheckAnswers
};

const renderField = resolvedProps => {
  const { displayMode, value = '', label = '' } = resolvedProps;

  const variant = displayMode === 'LABELS_LEFT' ? 'inline' : 'stacked';

  let val =
    value !== '' ? (
      <Text variant='h1' as='span'>
        {value}
      </Text>
    ) : (
      ''
    );

  if (label === 'Service Date')
    val = <DateInput value={value} style={{ fontSize: '14px' }}></DateInput>;

  if (label === 'Email')
    val = <Input type='email' value={value} style={{ fontSize: '14px' }}></Input>;

  if (label === 'First Name' || label === 'Last Name' || label === 'Middle Name')
    val = <Input value={value} style={{ fontSize: '14px' }}></Input>;

  if (label === 'Phone Number')
    val = <CosmosPhone value={value} style={{ fontSize: '14px' }}></CosmosPhone>;

  if (variant === 'inline') {
    val = value || <span aria-hidden='true'>&ndash;&ndash;</span>;
  } else {
    val = (
      <Text variant='h1' as='span'>
        {val}
      </Text>
    );
  }
  return <FieldValueList variant={variant} fields={[{ name: label, value: val }]} />;
};

export const BaseHmrcOdxCheckAnswers = () => {
  const props = {
    NumCols: 1,
    template: 'DefaultForm',
    getPConnect: () => {
      return {
        getChildren: () => {
          return pyReviewRaw.children;
        },
        createComponent: config => {
          // eslint-disable-next-line default-case
          switch (config.config.value) {
            case '@P .FirstName':
              return renderField(regionChildrenResolved[0]);
            case '@P .MiddleName':
              return renderField(regionChildrenResolved[1]);
            case '@P .LastName':
              return renderField(regionChildrenResolved[2]);
            case '@P .Email':
              return renderField(regionChildrenResolved[3]);
            case '@P .PhoneNumber':
              return renderField(regionChildrenResolved[4]);
            case '@P .ServiceDate':
              return renderField(regionChildrenResolved[5]);
          }
        }
      };
    }
  };

  const regionAChildren = pyReviewRaw.children[0].children.map(child => {
    return props.getPConnect().createComponent(child);
  });

  return <HmrcOdxCheckAnswers {...props}>{regionAChildren}</HmrcOdxCheckAnswers>;
};
