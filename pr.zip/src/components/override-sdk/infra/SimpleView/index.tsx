export { default } from './SimpleView';
