import React, { Fragment } from 'react';
import { Grid } from '@pega/cosmos-react-core';
import { useTranslation } from 'react-i18next';
import type { PConnProps } from '@pega/react-sdk-components/lib/types/PConnProps';
import StyledHmrcOdxGdsTaskListTemplateWrapper from './styles';
import './TaskListTemplate.css';

interface HmrcOdxGdsTaskListTemplateProps extends PConnProps {
  // If any, enter additional props that only exist on this componentName
  children: any[];
  cssClassHook: string;
  NumCols: string;
}

export default function HmrcOdxGdsTaskListTemplate(props: HmrcOdxGdsTaskListTemplateProps) {
  const { children, cssClassHook, NumCols, getPConnect } = props;
  const nCols = parseInt(NumCols, 8);
  const { t } = useTranslation();
  const context = getPConnect().getContextName();
  const caseInfo = getPConnect().getCaseSummary();
  const data = caseInfo.content.CaseTaskList;
  const caseType = caseInfo.content.CaseType;

  let totalSections = 0;
  let completedSections = 0;

  let cssHooks = '';
  if (caseType === 'Auth') {
    cssHooks = 'auth';
  } else {
    cssHooks = 'unauth';
  }

  // Loop through the data to determine the number of sections in total and how many are flagged as complete.
  data.forEach(task => {
    totalSections += 1;
    if (task.IsTaskComplete) {
      completedSections += 1;
    }
  });

  const handleOnClick = (section: any) => {
    getPConnect().setValue('.SelectedTask', section, '', false);
    getPConnect().getActionsApi().finishAssignment(context);
  };

  return (
    <StyledHmrcOdxGdsTaskListTemplateWrapper>
      <Grid
        className={`govuk-!-padding-bottom-4 ${cssClassHook} ${cssHooks}`}
        container={{
          cols: `repeat(${nCols}, minmax(0, 1fr))`,
          gap: 2
        }}
      >
        {children[0]}
      </Grid>
      <div className='govuk-!-padding-bottom-4'>
        <p className='govuk-body govuk-!-font-weight-bold'>
          {completedSections < totalSections
            ? `${t('CLAIM')} ${t('INCOMPLETE')}`
            : `${t('CLAIM')} ${t('COMPLETE')}`}
        </p>
        <p className='govuk-body govuk-!-padding-bottom-4'>
          {`${t('YOU_HAVE_COMPLETED')} ${completedSections} ${t('OF')} ${totalSections} ${t('SECTIONS')}`}
          .
        </p>
        <ul className='govuk-task-list'>
          {data &&
            data.map((task, index) => {
              const key = new Date().getTime() + index;
              return (
                <Fragment key={key}>
                  <li className='govuk-task-list__item govuk-task-list__item--with-link'>
                    <div className='govuk-task-list__name-and-hint'>
                      {task.IsTaskALink ? (
                        <a
                          className='govuk-link govuk-task-list__link'
                          href='#'
                          aria-describedby={`${task.TaskLabel.replaceAll(' ', '')}-${key}-status`}
                          onClick={() => handleOnClick(`${task.TaskLabel}`)}
                        >
                          {task.TaskLabel}
                        </a>
                      ) : (
                        <span>{task.TaskLabel}</span>
                      )}
                    </div>
                    {!task.IsTaskALink && !task.IsTaskInProgress && !task.IsTaskComplete && (
                      // cannot start
                      <div
                        className='govuk-task-list__status govuk-task-list__status--cannot-start-yet'
                        id={`${task.TaskLabel.replaceAll(' ', '')}-${key}-status`}
                      >
                        {task.TaskStatus}
                      </div>
                    )}

                    {task.IsTaskALink &&
                      !task.IsTaskInProgress &&
                      !task.IsTaskComplete && ( // to begin
                        <div
                          className='govuk-task-list__status'
                          id={`${task.TaskLabel.replaceAll(' ', '')}-${key}-status`}
                        >
                          <strong className='govuk-tag govuk-tag--blue'>{task.TaskStatus}</strong>
                        </div>
                      )}

                    {task.IsTaskALink &&
                      task.IsTaskInProgress &&
                      !task.IsTaskComplete && ( // in progress
                        <div
                          className='govuk-task-list__status'
                          id={`${task.TaskLabel.replaceAll(' ', '')}-${key}-status`}
                        >
                          <strong className='govuk-tag govuk-tag--light-blue'>
                            {task.TaskStatus}
                          </strong>
                        </div>
                      )}

                    {task.IsTaskALink &&
                      task.IsTaskInProgress &&
                      task.IsTaskComplete && ( // complete
                        <div
                          className='govuk-task-list__status'
                          id={`${task.TaskLabel.replaceAll(' ', '')}-${key}-status`}
                        >
                          <span>{task.TaskStatus}</span>
                        </div>
                      )}
                  </li>
                </Fragment>
              );
            })}
        </ul>
      </div>
      <Grid
        className='govuk-!-display-none'
        container={{
          cols: `repeat(${nCols}, minmax(0, 1fr))`,
          gap: 2
        }}
      >
        {children[1]}
      </Grid>
    </StyledHmrcOdxGdsTaskListTemplateWrapper>
  );
}
