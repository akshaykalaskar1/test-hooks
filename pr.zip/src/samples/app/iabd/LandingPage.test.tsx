import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import LandingPage from './LandingPage';
import { AnalyticsConfigProvider } from 'hmrc-odx-features-and-functions';

const mockSetAnnualCodingData = jest.fn();
const mockSetTaxYearStartDate = jest.fn();

let mockAnnualCodingData: any = null;

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useOutletContext: () => ({
    setCustomerDetails: jest.fn(),
    customerDetails: null,
    setAccessGroup: jest.fn(),
    accessGroup: null,
    setAnnualCodingData: mockSetAnnualCodingData,
    annualCodingData: mockAnnualCodingData,
    setTaxYearStartDate: mockSetTaxYearStartDate,
    taxYearStartDate: null
  })
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn().mockResolvedValue({
    serverConfig: {
      sdkContentServerUrl: 'http://mock-content-server',
      sdkHmrcURL: 'http://mock-hmrc-url'
    }
  })
}));

describe('LandingPage annualCoding CIPAttributes', () => {
  const baseProps = {
    redirectCurrentYearPage: jest.fn(),
    handleLinkClick: jest.fn(),
    redirectAnnualCodingTemplatePage: jest.fn(),
    userFullName: 'Test User'
  };

  const mockApiCallback = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('includes tracking attributes when templateValue is empty', () => {
    mockAnnualCodingData = {
      Customer: {
        TaxSummaryList: [
          {
            AnnualCodingAvailable: 'yes',
            TaxYearStartDate: '2026-04-06',
            TaxYearEndDate: '2027-04-05',
            pyTemplateDataField: ''
          }
        ]
      }
    };

    render(
      <AnalyticsConfigProvider apiCallback={mockApiCallback}>
        <LandingPage {...baseProps} />
      </AnalyticsConfigProvider>
    );

    const link = screen.getByRole('link', { name: /CHECK_NEXT_TAX_YEAR/i });

    expect(link).toHaveAttribute('data-tracking-type', 'Outbound');
    expect(link).toHaveAttribute(
      'data-tracking-target',
      expect.stringContaining('/check-income-tax/income-tax-comparison')
    );
  });

  test('does NOT include tracking attributes when templateValue is provided', () => {
    mockAnnualCodingData = {
      Customer: {
        TaxSummaryList: [
          {
            AnnualCodingAvailable: 'yes',
            TaxYearStartDate: '2026-04-06',
            TaxYearEndDate: '2027-04-05',
            pyTemplateDataField: 'CHECKYOURTAXCODE'
          }
        ]
      }
    };

    render(
      <AnalyticsConfigProvider apiCallback={mockApiCallback}>
        <LandingPage {...baseProps} />
      </AnalyticsConfigProvider>
    );

    const link = screen.getByRole('link', { name: /CHECK_NEXT_TAX_YEAR/i });

    expect(link).not.toHaveAttribute('data-tracking-type');
    expect(link).not.toHaveAttribute('data-tracking-target');
  });

  test('spread operator applies attributes into the DOM', () => {
    mockAnnualCodingData = {
      Customer: {
        TaxSummaryList: [
          {
            AnnualCodingAvailable: 'yes',
            TaxYearStartDate: '2026-04-06',
            TaxYearEndDate: '2027-04-05',
            pyTemplateDataField: ''
          }
        ]
      }
    };

    render(
      <AnalyticsConfigProvider apiCallback={mockApiCallback}>
        <LandingPage {...baseProps} />
      </AnalyticsConfigProvider>
    );

    const link = screen.getByRole('link', { name: /CHECK_NEXT_TAX_YEAR/i });

    expect(link.getAttributeNames()).toEqual(
      expect.arrayContaining(['data-tracking-type', 'data-tracking-target'])
    );
  });
});
