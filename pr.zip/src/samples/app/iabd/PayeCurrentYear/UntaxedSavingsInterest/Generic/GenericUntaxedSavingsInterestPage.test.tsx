import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import GenericUntaxedSavingsInterestPage from './GenericUntaxedSavingsInterestPage';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string, options?: any) => {
      if (options?.CurrentTaxYear) {
        return `${key}-${options.CurrentTaxYear}-${options.NextTaxStartYear}`;
      }

      return key;
    }
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <h1>{children}</h1>
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: any) => Component
}));

jest.mock('./GenericAllowanceSection', () => ({
  __esModule: true,
  default: ({ startingRateForSavingsAmount }: any) => <div data-testid='generic-allowance-section'>{startingRateForSavingsAmount}</div>
}));

jest.mock('./GenericTaxGuidanceSection', () => ({
  __esModule: true,
  default: ({ heading, paragraphs }: any) => (
    <div data-testid='generic-tax-guidance-section'>
      <div>{heading}</div>
      {paragraphs.map((paragraph: string) => (
        <div key={paragraph}>{paragraph}</div>
      ))}
    </div>
  )
}));

jest.mock('./GenericSavingsInterestDetails', () => ({
  __esModule: true,
  default: ({ savingsInterestThreshold }: any) => <div data-testid='generic-savings-interest-details'>{savingsInterestThreshold}</div>
}));

jest.mock('../components/MoreInformationSection', () => ({
  __esModule: true,
  default: () => <div data-testid='more-information-section'>More Information</div>
}));

describe('GenericUntaxedSavingsInterestPage', () => {
  const props = {
    CurrentTaxYear: '2025-26',
    savingsInterestThreshold: 10000,
    startingRateForSavings: 5000,
    NextTaxStartYear: '2026'
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is loaded, when rendered, then the title and introduction are displayed', () => {
    render(<GenericUntaxedSavingsInterestPage {...props} />);

    expect(screen.getByText('USI_TITLE')).toBeInTheDocument();
    expect(screen.getByText('USI_INTRODUCTION')).toBeInTheDocument();
  });

  test('Given tax year information exists, when rendered, then the introduction paragraphs contain the tax year values', () => {
    render(<GenericUntaxedSavingsInterestPage {...props} />);

    expect(screen.getByText('USI_GENERIC_INTRO-2025-26-2026')).toBeInTheDocument();

    expect(screen.getByText('USI_ESTIMATED_MESSAGE-2025-26-2026')).toBeInTheDocument();
  });

  test('Given a starting rate for savings amount exists, when rendered, then the GenericAllowanceSection is displayed with the amount', () => {
    render(<GenericUntaxedSavingsInterestPage {...props} />);

    expect(screen.getByText('5000')).toBeInTheDocument();
  });

  test('Given guidance content exists, when rendered, then the GenericTaxGuidanceSection is displayed with the heading and paragraphs', () => {
    render(<GenericUntaxedSavingsInterestPage {...props} />);

    expect(screen.getByText('USI_GENERIC_GUIDANCE_HEADING')).toBeInTheDocument();
    expect(screen.getByText('USI_GENERIC_GUIDANCE_P1')).toBeInTheDocument();
    expect(screen.getByText('USI_GENERIC_GUIDANCE_P2')).toBeInTheDocument();
    expect(screen.getByText('USI_GENERIC_GUIDANCE_P3')).toBeInTheDocument();
  });

  test('Given a savings interest threshold exists, when rendered, then the GenericSavingsInterestDetails component is displayed with the threshold amount', () => {
    render(<GenericUntaxedSavingsInterestPage {...props} />);

    expect(screen.getByText('10000')).toBeInTheDocument();
  });
});
