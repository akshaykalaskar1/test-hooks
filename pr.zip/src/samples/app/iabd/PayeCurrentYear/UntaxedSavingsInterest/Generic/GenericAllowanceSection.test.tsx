import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import GenericAllowanceSection from './GenericAllowanceSection';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string, options?: any) => {
      if (key === 'USI_GENERIC_ALLOWANCE_P3') {
        return `USI_GENERIC_ALLOWANCE_P3 ${options?.amount}`;
      }

      return key;
    }
  })
}));

describe('GenericAllowanceSection', () => {
  test('renders heading and paragraphs', () => {
    render(<GenericAllowanceSection startingRateForSavingsAmount={5000} />);

    expect(screen.getByText('USI_GENERIC_ALLOWANCE_HEADING')).toBeInTheDocument();

    expect(screen.getByText('USI_GENERIC_ALLOWANCE_P1')).toBeInTheDocument();

    expect(screen.getByText(content => content.includes('USI_GENERIC_ALLOWANCE_P2'))).toBeInTheDocument();
  });

  test('renders links', () => {
    render(<GenericAllowanceSection startingRateForSavingsAmount={5000} />);

    expect(
      screen.getByRole('link', {
        name: /USI_PSA_LINK/i
      })
    ).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance');

    expect(
      screen.getByRole('link', {
        name: /USI_STARTING_RATE_LINK/i
      })
    ).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings');
  });

  test('renders dynamic starting rate amount', () => {
    render(<GenericAllowanceSection startingRateForSavingsAmount={5000} />);

    expect(screen.getByText(/USI_GENERIC_ALLOWANCE_P3 £5,000/)).toBeInTheDocument();
  });
});
