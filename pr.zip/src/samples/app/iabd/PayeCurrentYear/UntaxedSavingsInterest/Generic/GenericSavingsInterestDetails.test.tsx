import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import GenericSavingsInterestDetails from './GenericSavingsInterestDetails';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string, options?: any) => {
      if (key === 'USI_GENERIC_DETAILS_P1') {
        return `USI_GENERIC_DETAILS_P1 ${options?.savingsInterestThreshold}`;
      }

      return key;
    }
  })
}));

jest.mock('hmrc-gds-react-components', () => {
  const Link = ({ children, ...props }: any) => <a {...props}>{children}</a>;

  return {
    __esModule: true,
    Link
  };
});

describe('GenericSavingsInterestDetails', () => {
  const props = {
    savingsInterestThreshold: 10000
  };

  test('renders heading', () => {
    render(<GenericSavingsInterestDetails {...props} />);

    expect(screen.getByText('USI_GENERIC_DETAILS_HEADING')).toBeInTheDocument();
  });

  test('renders dynamic savings interest threshold', () => {
    render(<GenericSavingsInterestDetails {...props} />);

    expect(screen.getByText(/USI_GENERIC_DETAILS_P1 £10,000/)).toBeInTheDocument();
  });

  test('renders self assessment link', () => {
    render(<GenericSavingsInterestDetails {...props} />);

    const link = screen.getByRole('link', {
      name: 'USI_DETAILS_LINK'
    });

    expect(link).toBeInTheDocument();

    expect(link).toHaveAttribute('href', 'https://www.gov.uk/log-in-file-self-assessment-tax-return');

    expect(link).toHaveAttribute('target', '_blank');

    expect(link).toHaveAttribute('rel', 'noreferrer noopener');

    expect(link).toHaveAttribute('data-tracking-type', 'Outbound');

    expect(link).toHaveAttribute('data-tracking-target', 'https://www.gov.uk/log-in-file-self-assessment-tax-return');
  });
});
