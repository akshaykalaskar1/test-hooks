export interface UntaxedSavingsInterestApiResponse {
  fetchDateTime: string;
  resultCount: number;

  data: Array<{
    pyErrors?: object;
    Customer: {
      TaxSummaryList: Array<{
        pyTemplateDataField: string;
        EstimatedUSI: string;
        PSA: string | null;
        TaxToPay: string;
      }>;
    };
  }>;
}
