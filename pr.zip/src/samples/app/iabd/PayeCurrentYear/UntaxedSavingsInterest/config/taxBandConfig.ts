export interface TaxBandConfig {
  allowanceText: string;
  contactUsMessage: string;
  showSummaryTable: boolean;
  introParagraphs: readonly string[];
  guidanceHeading: string;
  guidanceParagraphs: readonly string[];
  guidanceBullets: readonly string[];
  detailsHeading: string;
  CIP_EventID: string;

  showStartingRateParagraph: boolean;
  isAdditionalRate: boolean;
  showTPHigherLayout?: boolean;
  showTPAdditionalLayout?: boolean;
}

export const TAX_BAND_CONFIG: Record<string, TaxBandConfig> = {
  'BELOW-BASIC': {
    allowanceText: '',

    contactUsMessage: 'USI_CONTACT_MESSAGE_ALLOWANCES',

    showStartingRateParagraph: true,
    isAdditionalRate: false,

    showSummaryTable: false,

    introParagraphs: [],

    guidanceHeading: 'USI_GUIDANCE_HEADING',

    guidanceParagraphs: ['USI_GUIDANCE_DEFAULT'],

    guidanceBullets: ['USI_BULLET_ALLOWANCES_1', 'USI_BULLET_ALLOWANCES_2'],

    detailsHeading: 'USI_DETAILS_HEADING_ALLOWANCES',

    CIP_EventID: 'Untaxed Interest-Under PSA-Below Basic Rate'
  },

  BASIC: {
    allowanceText: 'USI_ALLOWANCE_TEXT_BASIC',

    contactUsMessage: 'USI_CONTACT_MESSAGE_PSA',

    showStartingRateParagraph: true,
    isAdditionalRate: false,
    showSummaryTable: true,

    introParagraphs: [],

    guidanceHeading: 'USI_GUIDANCE_HEADING',

    guidanceParagraphs: ['USI_GUIDANCE_DEFAULT'],

    guidanceBullets: ['USI_BULLET_PSA_1', 'USI_BULLET_PSA_2'],

    detailsHeading: 'USI_DETAILS_HEADING_PSA',

    CIP_EventID: 'Untaxed Interest-Under PSA-Basic Rate'
  },

  'GENERIC-USI': {
    allowanceText: 'USI_ALLOWANCE_TEXT_GENERIC',

    contactUsMessage: '',

    showStartingRateParagraph: true,

    isAdditionalRate: false,

    showSummaryTable: false,

    introParagraphs: ['USI_GENERIC_INTRO', 'USI_ESTIMATED_MESSAGE'],

    guidanceHeading: 'USI_GENERIC_GUIDANCE_HEADING',

    guidanceParagraphs: ['USI_GENERIC_GUIDANCE_P1', 'USI_GENERIC_GUIDANCE_P2', 'USI_GENERIC_GUIDANCE_P3'],
    guidanceBullets: [],

    detailsHeading: 'USI_GENERIC_DETAILS_HEADING',

    CIP_EventID: 'Untaxed Interest-Generic explainer'
  },

  HIGHER: {
    allowanceText: 'USI_ALLOWANCE_TEXT_BASIC',

    contactUsMessage: 'USI_CONTACT_MESSAGE_PSA',

    showStartingRateParagraph: false,
    isAdditionalRate: false,

    showSummaryTable: true,

    introParagraphs: [],

    guidanceParagraphs: ['USI_GUIDANCE_DEFAULT'],

    guidanceHeading: 'USI_GUIDANCE_HEADING',

    guidanceBullets: ['USI_BULLET_PSA_1', 'USI_BULLET_PSA_2'],

    detailsHeading: 'USI_DETAILS_HEADING_PSA',

    CIP_EventID: 'Untaxed Interest-Under PSA-Higher Rate'
  },

  'TP-HIGHER': {
    allowanceText: '',

    contactUsMessage: '',

    showStartingRateParagraph: false,
    isAdditionalRate: false,
    showTPHigherLayout: true,

    showSummaryTable: true,

    introParagraphs: [],

    guidanceParagraphs: ['USI_TP_GUIDANCE_P1', 'USI_TP_GUIDANCE_P2', 'USI_TP_GUIDANCE_P3', 'USI_TP_GUIDANCE_P4', 'USI_TP_GUIDANCE_P5'],

    guidanceHeading: 'USI_TP_GUIDANCE_HEADING',

    guidanceBullets: [],

    detailsHeading: '',

    CIP_EventID: 'Untaxed Interest-Above PSA-Higher Rate'
  },

  'TP-ADDITIONAL': {
    allowanceText: '',

    contactUsMessage: '',

    showStartingRateParagraph: false,
    isAdditionalRate: false,
    showTPAdditionalLayout: true,

    showSummaryTable: true,

    introParagraphs: [],

    guidanceParagraphs: ['USI_TP_GUIDANCE_P1', 'USI_TP_GUIDANCE_P2', 'USI_TP_GUIDANCE_P3', 'USI_TP_GUIDANCE_P4', 'USI_TP_GUIDANCE_P5'],

    guidanceHeading: 'USI_TP_GUIDANCE_HEADING',

    guidanceBullets: [],

    detailsHeading: '',

    CIP_EventID: 'Untaxed Interest-Above PSA-Additional Rate'
  }
} as const;
