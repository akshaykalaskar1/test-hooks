import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import MainWrapperFull from '../../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import LoadingWrapper from '../../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import setPageTitle from '../../../../../components/helpers/setPageTitleHelpers';
import ErrorMessage from '../../ErrorPage/errorMessage';
import UntaxedSavingsInterestPage from './components/UntaxedSavingsInterestPage';
import { mapUntaxedSavingsInterest } from './mappers/untaxedSavingsInterestMapper';
import { UntaxedSavingsInterestApiResponse } from './models/UntaxedSavingsInterestApiResponse';
import { UntaxedSavingsInterestViewModel } from './models/UntaxedSavingsInterestViewModel';
import Button from '../../../../../components/BaseComponents/Button/Button';
import GenericUntaxedSavingsInterestPage from './Generic/GenericUntaxedSavingsInterestPage';

interface UntaxedSavingsInterestProps {
  CurrentTaxYear: number;
  savingsInterestThreshold: string;
  startingRateForSavings: string;
  NextTaxStartYear: number;
  genericUntaxedSavingsInterest: boolean;
}

const UntaxedSavingsInterestLanding = ({
  CurrentTaxYear,
  NextTaxStartYear,
  savingsInterestThreshold,
  startingRateForSavings,
  genericUntaxedSavingsInterest
}: UntaxedSavingsInterestProps) => {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(!genericUntaxedSavingsInterest);
  const [error, setError] = useState<boolean>(false);
  const [viewModel, setViewModel] = useState<UntaxedSavingsInterestViewModel | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setPageTitle();
  }, [t]);

  const handleBackClick = (e: React.MouseEvent) => {
    e.preventDefault();

    navigate(-1);
  };

  const fetchUntaxedSavingsInterest = async () => {
    setIsLoading(true);
    try {
      const response = (await PCore.getDataPageUtils().getDataAsync('D_UntaxedSavingInterest', 'root', {})) as UntaxedSavingsInterestApiResponse;
      const pegaError = response?.data[0]?.pyErrors;
      if (pegaError) {
        setError(true);
        return;
      }

      const vm = mapUntaxedSavingsInterest(response as UntaxedSavingsInterestApiResponse, {
        CurrentTaxYear,
        NextTaxStartYear,
        savingsInterestThreshold,
        startingRateForSavings
      });

      setViewModel(vm);
    } catch (err) {
      console.error('Error fetching Untaxed Savings Interest:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!genericUntaxedSavingsInterest) {
      fetchUntaxedSavingsInterest();
    }
  }, []);

  return (
    <LoadingWrapper
      pageIsLoading={isLoading}
      spinnerProps={{
        bottomText: t('LOADING'),
        label: t('LOADING')
      }}
    >
      <>
        {error && <ErrorMessage />}

        {!error && (viewModel || genericUntaxedSavingsInterest) && (
          <>
            <Button variant='backlink' onClick={handleBackClick} attributes={{ type: 'link' }} />
            <MainWrapperFull title={t(viewModel?.title, { lang: 'en' })}>
              {viewModel?.showGenericLayout || genericUntaxedSavingsInterest ? (
                <GenericUntaxedSavingsInterestPage
                  pageName='Untaxed Interest-Generic explainer'
                  CurrentTaxYear={CurrentTaxYear}
                  NextTaxStartYear={NextTaxStartYear}
                  savingsInterestThreshold={savingsInterestThreshold}
                  startingRateForSavings={startingRateForSavings}
                />
              ) : (
                <UntaxedSavingsInterestPage viewModel={viewModel} pageName={viewModel.CIP_EventID} />
              )}
            </MainWrapperFull>
          </>
        )}
      </>
    </LoadingWrapper>
  );
};

export default UntaxedSavingsInterestLanding;
