import React from 'react';
import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import UntaxedSavingsInterestPage from './UntaxedSavingsInterestPage';
import { renderHook } from '@testing-library/react-hooks';

import { AnalyticsConfigProvider } from 'hmrc-odx-features-and-functions';

import renderWithRouter from '../../../../../../../tests/utils/renderWithRouter';
import { mockGetSdkConfigWithBasepath } from '../../../../../../../tests/mocks/getSdkConfigMock';
import { mockNavigate } from '../../../../../../../tests/mocks/routerMocks';
import useHMRCExternalLinks from '../../../../../../components/helpers/hooks/HMRCExternalLinks';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate
}));

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

// Mock the translation hook
jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

const mockApiCallback = jest.fn();

describe('UntaxedSavingsInterestPage', () => {
  const mockRedirectToUnderstandYourTaxPage = jest.fn();
  const mockRedirectToViewTimelineDetailsPage = jest.fn();

  afterEach(cleanup);

  beforeEach(async () => {
    mockRedirectToUnderstandYourTaxPage.mockClear();
    mockGetSdkConfigWithBasepath();
    const { result } = renderHook(() => useHMRCExternalLinks());
    await act(async () => {
      result.current.referrerURL = 'https://www.staging.tax.service.gov.uk/';
      result.current.hmrcURL = 'https://www.staging.tax.service.gov.uk/';
    });
  });

  const props = {
    redirectToUnderstandYourTaxPage: mockRedirectToUnderstandYourTaxPage,
    redirectToViewTimelineDetailsPage: mockRedirectToViewTimelineDetailsPage,
    comingFromPage: 'UnderstandYourTaxCodePage'
  };

  const getComponent = () => {
    return (
      <AnalyticsConfigProvider apiCallback={mockApiCallback}>
        <UntaxedSavingsInterestPage {...props} />
      </AnalyticsConfigProvider>
    );
  };

  it('renders the page title and content', async () => {
    act(() => {
      renderWithRouter(getComponent());
    });

    // Check if the title is rendered
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('UNTAXED_SAVINGS_INTEREST.UNTAXED_SAVINGS_INTEREST_TITLE');

    // Check if some body content is rendered
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.DESCRIPTION_1')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.DESCRIPTION_2')).toBeInTheDocument();
  });

  it('navigates back when clicking the backlink', async () => {
    renderWithRouter(getComponent());
    // Check if the backlink button is rendered
    const backLink = await screen.findByText('BACK');
    // Simulate a click event
    fireEvent.click(backLink);

    // Check if the redirect function is called
    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  it('renders all sections and headings', async () => {
    act(() => {
      renderWithRouter(getComponent());
    });

    // Check if all headings are rendered
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.WHY_IN_TAX_CODE')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.SELF_ASSESSMENT')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.NO_SELF_ASSESSMENT')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.PERSONAL_SAVINGS_ALLOWANCE')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.FIGURE_MISMATCH')).toBeInTheDocument();
    expect(screen.getByText('UNTAXED_SAVINGS_INTEREST.MORE_HELP')).toBeInTheDocument();
  });

  it('renders the external link with correct aria-label', async () => {
    act(() => {
      renderWithRouter(getComponent());
    });

    // Check if the external link is rendered
    const externalLink = screen.getByRole('link', {
      name: 'UNTAXED_SAVINGS_INTEREST.MORE_HELP_LINK_TEXT'
    });
    expect(externalLink).toBeInTheDocument();
    expect(externalLink).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings?lang=en');
  });
});
