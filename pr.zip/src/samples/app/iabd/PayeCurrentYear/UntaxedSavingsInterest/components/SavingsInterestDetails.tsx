import { useTranslation } from 'react-i18next';
import { Details, Link } from 'hmrc-gds-react-components';
import { currencyFormatter } from '../../../../../../components/helpers/utils';

interface Props {
  heading: string;
  savingsInterestThreshold: number;
}

const SavingsInterestDetails = ({ heading, savingsInterestThreshold }: Props) => {
  const { t } = useTranslation();

  return (
    <Details>
      <Details.Header>{heading}</Details.Header>
      <Details.Content>
        <p className='govuk-body'>{t('USI_DETAILS_P1')}</p>

        <p className='govuk-body'>
          {t('USI_DETAILS_P2_PREFIX', {
            amount: currencyFormatter(savingsInterestThreshold.toLocaleString())
          })}{' '}
          <Link
            href='https://www.gov.uk/log-in-file-self-assessment-tax-return'
            target='_blank'
            rel='noreferrer noopener'
            data-tracking-type='Outbound'
            data-tracking-target='https://www.gov.uk/log-in-file-self-assessment-tax-return'
          >
            {t('USI_DETAILS_LINK')}
          </Link>
          .
        </p>

        <p className='govuk-body'>{t('USI_DETAILS_P3')}</p>
      </Details.Content>
    </Details>
  );
};

export default SavingsInterestDetails;
