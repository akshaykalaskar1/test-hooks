import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import renderWithRouter from '../../../../../../../tests/utils/renderWithRouter';
import MoreInformationSection from './MoreInformationSection';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

describe('MoreInformationSection', () => {
  test('renders heading', () => {
    renderWithRouter(<MoreInformationSection />);

    expect(screen.getByText('USI_MORE_INFORMATION_HEADING')).toBeInTheDocument();
  });

  test('renders link', () => {
    renderWithRouter(<MoreInformationSection />);

    const link = screen.getByRole('link', {
      name: 'USI_MORE_INFORMATION_LINK'
    });

    expect(link).toHaveAttribute('href', '#');
  });
});
