import { Heading, SummaryList, SummaryListRow } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { currencyFormatter } from '../../../../../../components/helpers/utils';

interface Props {
  EstimatedUSI: string;
  showSummaryTable?: boolean;
  PSA?: string;
  TaxableAmount?: string;
  TaxToPay?: string;
  CurrentTaxYear?: number;
  NextTaxStartYear?: number;
  showTPHigherLayout?: boolean;
  showTPAdditionalLayout?: boolean;
}

const EstimatedInterestSection = ({
  EstimatedUSI,
  showSummaryTable,
  PSA,
  TaxableAmount,
  TaxToPay,
  CurrentTaxYear,
  NextTaxStartYear,
  showTPHigherLayout,
  showTPAdditionalLayout
}: Props) => {
  const { t } = useTranslation();
  const summaryRows =
    showTPHigherLayout || showTPAdditionalLayout
      ? [
          {
            translationKey: 'USI_ESTIMATED_ROW',
            value: currencyFormatter(EstimatedUSI)
          },
          {
            translationKey: 'USI_PSA_ROW',
            value: currencyFormatter(PSA)
          }
        ]
      : [
          {
            translationKey: 'USI_ESTIMATED_ROW',
            value: currencyFormatter(EstimatedUSI)
          },
          {
            translationKey: 'USI_PSA_ROW',
            value: currencyFormatter(PSA)
          },
          {
            translationKey: 'USI_TAX_TO_PAY_ROW',
            value: currencyFormatter(TaxToPay)
          }
        ];

  return (
    <>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('USI_ESTIMATED_HEADING')}
      </Heading>

      {showTPHigherLayout || showTPAdditionalLayout ? (
        <>
          <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_YEAR', { CurrentTaxYear, NextTaxStartYear })}</p>
          <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_INFO')}</p>
        </>
      ) : (
        <p className='govuk-body'>{t('USI_ESTIMATED_MESSAGE', { CurrentTaxYear, NextTaxStartYear })}</p>
      )}

      {showSummaryTable && !showTPHigherLayout && !showTPAdditionalLayout ? (
        <>
          <SummaryList>
            {summaryRows.map(({ translationKey, value }) => (
              <SummaryListRow
                key={translationKey}
                label={t(translationKey)}
                value={value}
                classes={{ key: 'govuk-!-font-weight-regular govuk-!-width-two-thirds' }}
              />
            ))}
          </SummaryList>

          <p className='govuk-body'>{t('USI_WITHIN_PSA')}</p>
        </>
      ) : showTPHigherLayout || showTPAdditionalLayout ? (
        <>
          <SummaryList>
            {summaryRows.map(({ translationKey, value }) => (
              <SummaryListRow
                key={translationKey}
                label={t(translationKey)}
                value={value}
                classes={{ key: 'govuk-!-font-weight-regular govuk-!-width-two-thirds' }}
              />
            ))}
          </SummaryList>

          {showTPHigherLayout && (
            <>
              <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_ABOVE_PSA', { amount: currencyFormatter(TaxableAmount) })}</p>
              <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_PAY')}</p>
            </>
          )}

          {showTPAdditionalLayout && (
            <>
              <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_NO_PSA')}</p>
              <p className='govuk-body'>{t('USI_TP_ESTIMATED_MESSAGE_PAY_ALL')}</p>
            </>
          )}
        </>
      ) : (
        <>
          <p className='govuk-body'>
            {t('USI_ESTIMATED_AMOUNT', {
              amount: EstimatedUSI
            })}
          </p>

          <p className='govuk-body'>{t('USI_NO_TAX')}</p>
        </>
      )}
    </>
  );
};

export default EstimatedInterestSection;
