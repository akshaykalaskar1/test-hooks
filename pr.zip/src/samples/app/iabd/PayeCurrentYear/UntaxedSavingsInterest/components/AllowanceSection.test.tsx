import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import AllowanceSection from './AllowanceSection';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

const PSA_URL = 'https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance';

const STARTING_RATE_URL = 'https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings';

describe('AllowanceSection', () => {
  const defaultProps = {
    allowanceText: 'USI_ALLOWANCE_TEXT_BASIC',
    personalSavingsAllowanceAmount: 1000,
    startingRateForSavingsAmount: 5000,
    showStartingRateParagraph: false,
    isAdditionalRate: false
  };

  test('Given no allowance text exists, when rendered, then nothing is displayed', () => {
    const { container } = render(<AllowanceSection {...defaultProps} allowanceText='' showTPHigherLayout={false} />);

    expect(container.firstChild).toBeNull();
  });

  test('Given an additional rate taxpayer, when rendered, then additional rate content is displayed', () => {
    render(<AllowanceSection {...defaultProps} isAdditionalRate />);

    expect(screen.getByText(/USI_ALLOWANCE_TEXT_BASIC/i)).toBeInTheDocument();

    expect(screen.getByRole('link')).toHaveAttribute('href', PSA_URL);
  });

  test('Given a non additional rate taxpayer, when rendered, then allowance amount is displayed', () => {
    render(<AllowanceSection {...defaultProps} />);

    expect(screen.getByText(/1,000/i)).toBeInTheDocument();

    expect(screen.getByRole('link')).toHaveAttribute('href', PSA_URL);
  });

  test('Given TP higher layout is enabled, when rendered, then TP guidance is displayed', () => {
    render(<AllowanceSection {...defaultProps} allowanceText='' showTPHigherLayout />);

    expect(screen.getByText(/USI_TP_ALLOWANCE_GUIDANCE/i)).toBeInTheDocument();

    expect(screen.getByRole('link')).toHaveAttribute('href', PSA_URL);
  });

  test('Given starting rate paragraph flag is true, when rendered, then starting rate content is displayed', () => {
    render(<AllowanceSection {...defaultProps} showStartingRateParagraph />);

    expect(screen.getByText(/USI_STARTING_RATE_PREFIX/i)).toBeInTheDocument();

    expect(screen.getByText(/5,000/i)).toBeInTheDocument();

    const startingRateLink = screen.getByRole('link', {
      name: /USI_STARTING_RATE_LINK/i
    });

    expect(startingRateLink).toBeInTheDocument();
    expect(startingRateLink).toHaveAttribute('href', STARTING_RATE_URL);
  });

  test('Given starting rate paragraph flag is false, when rendered, then starting rate content is not displayed', () => {
    render(<AllowanceSection {...defaultProps} showStartingRateParagraph={false} />);

    expect(screen.queryByText(/USI_STARTING_RATE_PREFIX/i)).not.toBeInTheDocument();
  });
});
