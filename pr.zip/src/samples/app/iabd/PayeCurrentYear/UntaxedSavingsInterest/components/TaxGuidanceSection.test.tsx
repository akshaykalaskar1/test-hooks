import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import TaxGuidanceSection from './TaxGuidanceSection';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  __esModule: true,

  Heading: ({ children }: any) => <h2>{children}</h2>,

  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

describe('TaxGuidanceSection', () => {
  const props = {
    heading: 'Tax guidance heading',
    paragraphs: ['First guidance paragraph', 'Second guidance paragraph'],
    bullets: ['First bullet', 'Second bullet']
  };

  test('renders heading', () => {
    render(<TaxGuidanceSection {...props} />);

    expect(screen.getByText('Tax guidance heading')).toBeInTheDocument();
  });

  test('renders paragraphs', () => {
    render(<TaxGuidanceSection {...props} />);

    expect(screen.getByText('First guidance paragraph')).toBeInTheDocument();

    expect(screen.getByText('Second guidance paragraph')).toBeInTheDocument();
  });

  test('renders bullet points', () => {
    render(<TaxGuidanceSection {...props} />);

    expect(screen.getByText('First bullet')).toBeInTheDocument();

    expect(screen.getByText('Second bullet')).toBeInTheDocument();
  });

  test('renders allowance guidance content when enabled', () => {
    render(<TaxGuidanceSection {...props} showAllowanceGuidance />);

    expect(screen.getByText(/USI_ALLOWANCE_GUIDANCE_P1/)).toBeInTheDocument();

    expect(screen.getByText(/USI_ALLOWANCE_GUIDANCE_P2/)).toBeInTheDocument();

    expect(
      screen.getByRole('link', {
        name: /USI_ALLOWANCE_GUIDANCE_PSA_LINK/i
      })
    ).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance');

    expect(
      screen.getByRole('link', {
        name: /USI_ALLOWANCE_GUIDANCE_STARTING_RATE_LINK/i
      })
    ).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings');
  });

  test('does not render allowance guidance content when disabled', () => {
    render(<TaxGuidanceSection {...props} showAllowanceGuidance={false} />);

    expect(screen.queryByText('USI_ALLOWANCE_GUIDANCE_P1')).not.toBeInTheDocument();

    expect(screen.queryByText('USI_ALLOWANCE_GUIDANCE_P2')).not.toBeInTheDocument();
  });
});
