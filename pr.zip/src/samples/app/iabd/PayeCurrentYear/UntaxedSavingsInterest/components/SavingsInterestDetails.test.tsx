import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import SavingsInterestDetails from './SavingsInterestDetails';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string, options?: any) => {
      if (key === 'USI_DETAILS_P2_PREFIX') {
        return `USI_DETAILS_P2_PREFIX ${options?.amount}`;
      }

      return key;
    }
  })
}));

jest.mock('hmrc-gds-react-components', () => {
  const Details: any = ({ children }: any) => <div data-testid='details'>{children}</div>;

  Details.Header = ({ children }: any) => <div data-testid='details-header'>{children}</div>;

  Details.Content = ({ children }: any) => <div data-testid='details-content'>{children}</div>;

  const Link = ({ children, ...props }: any) => <a {...props}>{children}</a>;

  return {
    __esModule: true,
    Details,
    Link
  };
});

describe('SavingsInterestDetails', () => {
  const props = {
    heading: 'Details heading',
    savingsInterestThreshold: 10000
  };

  test('renders heading and content', () => {
    render(<SavingsInterestDetails {...props} />);

    expect(screen.getByText('Details heading')).toBeInTheDocument();

    expect(screen.getByText('USI_DETAILS_P1')).toBeInTheDocument();

    expect(screen.getByText('USI_DETAILS_P3')).toBeInTheDocument();
  });

  test('renders self assessment link', () => {
    render(<SavingsInterestDetails {...props} />);

    const link = screen.getByRole('link', {
      name: 'USI_DETAILS_LINK'
    });

    expect(link).toBeInTheDocument();

    expect(link).toHaveAttribute('href', 'https://www.gov.uk/log-in-file-self-assessment-tax-return');

    expect(link).toHaveAttribute('target', '_blank');

    expect(link).toHaveAttribute('rel', 'noreferrer noopener');

    expect(link).toHaveAttribute('data-tracking-type', 'Outbound');

    expect(link).toHaveAttribute('data-tracking-target', 'https://www.gov.uk/log-in-file-self-assessment-tax-return');
  });

  test('renders dynamic savings interest threshold', () => {
    render(<SavingsInterestDetails {...props} />);
    expect(screen.getByText(/USI_DETAILS_P2_PREFIX £10,000/)).toBeInTheDocument();
  });
});
