import { Link } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { currencyFormatter } from '../../../../../../components/helpers/utils';

interface Props {
  allowanceText: string;
  personalSavingsAllowanceAmount: number;
  startingRateForSavingsAmount: number;
  showStartingRateParagraph: boolean;
  isAdditionalRate: boolean;
  showTPHigherLayout?: boolean;
}

const AllowanceSection = ({
  allowanceText,
  personalSavingsAllowanceAmount,
  startingRateForSavingsAmount,
  showStartingRateParagraph,
  isAdditionalRate,
  showTPHigherLayout
}: Props) => {
  const { t } = useTranslation();

  if (!allowanceText && !showTPHigherLayout) {
    return null;
  }

  return (
    <>
      {isAdditionalRate ? (
        <p className='govuk-body'>
          {t(allowanceText)}{' '}
          <Link
            href='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
            target='_blank'
            rel='noreferrer noopener'
            data-tracking-type='Outbound'
            data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
          >
            {t('USI_PSA_LINK')} {t('OPENS_IN_NEW_TAB')}
          </Link>
          .
        </p>
      ) : showTPHigherLayout ? (
        <p className='govuk-body'>
          {t('USI_TP_ALLOWANCE_GUIDANCE')}{' '}
          <Link
            href='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
            target='_blank'
            rel='noreferrer noopener'
            data-tracking-type='Outbound'
            data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
          >
            {t('USI_PSA_LINK')} {t('OPENS_IN_NEW_TAB')}
          </Link>
          .
        </p>
      ) : (
        <p className='govuk-body'>
          {t(allowanceText)} {currencyFormatter(personalSavingsAllowanceAmount.toLocaleString())} {t('USI_OF_INTEREST_WITHOUT_TAX')}{' '}
          <Link
            href='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
            target='_blank'
            rel='noreferrer noopener'
            data-tracking-type='Outbound'
            data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
          >
            {t('USI_PSA_LINK')} {t('OPENS_IN_NEW_TAB')}
          </Link>
          .
        </p>
      )}

      {showStartingRateParagraph && (
        <p className='govuk-body'>
          {t('USI_STARTING_RATE_PREFIX')} {currencyFormatter(startingRateForSavingsAmount.toLocaleString())} {t('USI_STARTING_RATE_SUFFIX')}{' '}
          <Link
            href='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
            target='_blank'
            rel='noreferrer noopener'
            data-tracking-type='Outbound'
            data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
          >
            {t('USI_STARTING_RATE_LINK')} {t('OPENS_IN_NEW_TAB')}
          </Link>
          .
        </p>
      )}
    </>
  );
};

export default AllowanceSection;
