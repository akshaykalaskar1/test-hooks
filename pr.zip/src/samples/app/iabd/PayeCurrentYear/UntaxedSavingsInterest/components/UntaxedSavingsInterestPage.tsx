import { useTranslation } from 'react-i18next';

import { UntaxedSavingsInterestViewModel } from '../models/UntaxedSavingsInterestViewModel';

import AllowanceSection from './AllowanceSection';
import ContactUsSection from './ContactUsSection';
import EstimatedInterestSection from './EstimatedInterestSection';
import SavingsInterestDetails from './SavingsInterestDetails';
import TaxGuidanceSection from './TaxGuidanceSection';
import MoreInformationSection from './MoreInformationSection';
import GenericTaxGuidanceSection from './../Generic/GenericTaxGuidanceSection';
import GenericSavingsInterestDetails from '../Generic/GenericSavingsInterestDetails';
import GenericAllowanceSection from '../Generic/GenericAllowanceSection';
import { Heading } from 'hmrc-gds-react-components';
import { withPageTracking } from 'hmrc-odx-features-and-functions';

interface Props {
  viewModel: UntaxedSavingsInterestViewModel;
  pageName: string;
}

const UntaxedSavingsInterestPage = ({ viewModel }: Props) => {
  const { t } = useTranslation();

  return (
    <div className='govuk-grid-row'>
      <div className='govuk-grid-column-two-thirds'>
        <Heading headingLevel={1} className='govuk-heading-l'>
          {t(viewModel.title)}
        </Heading>

        <p className='govuk-body'>{t(viewModel.introduction)}</p>
        {viewModel.introParagraphs.map(paragraph => (
          <p key={paragraph} className='govuk-body'>
            {t(paragraph, {
              CurrentTaxYear: viewModel.CurrentTaxYear,
              NextTaxStartYear: viewModel.NextTaxStartYear
            })}
          </p>
        ))}

        {viewModel.showGenericLayout ? (
          <GenericAllowanceSection startingRateForSavingsAmount={viewModel.startingRateForSavingsAmount} />
        ) : (
          <AllowanceSection
            allowanceText={viewModel.allowanceText}
            personalSavingsAllowanceAmount={viewModel.personalSavingsAllowanceAmount}
            startingRateForSavingsAmount={viewModel.startingRateForSavingsAmount}
            showStartingRateParagraph={viewModel.showStartingRateParagraph}
            isAdditionalRate={viewModel.isAdditionalRate}
            showTPHigherLayout={viewModel.showTPHigherLayout}
          />
        )}

        {!viewModel.showGenericLayout && (
          <EstimatedInterestSection
            EstimatedUSI={viewModel.EstimatedUSI}
            CurrentTaxYear={viewModel.CurrentTaxYear}
            NextTaxStartYear={viewModel.NextTaxStartYear}
            showSummaryTable={!!viewModel.summaryTable}
            PSA={viewModel.summaryTable?.PSA}
            TaxToPay={viewModel.summaryTable?.TaxToPay}
            TaxableAmount={viewModel.TaxableAmount}
            showTPHigherLayout={viewModel.showTPHigherLayout}
            showTPAdditionalLayout={viewModel.showTPAdditionalLayout}
          />
        )}

        {/* TODO : showAllowanceGuidance will be taken from view model's template type in upcoming sprint */}

        {viewModel.showGenericLayout ? (
          <GenericTaxGuidanceSection
            heading={t(viewModel.taxGuidance.heading)}
            paragraphs={viewModel.taxGuidance.paragraphs.map(paragraph => t(paragraph))}
          />
        ) : (
          <TaxGuidanceSection
            heading={t(viewModel.taxGuidance.heading)}
            paragraphs={viewModel.taxGuidance.paragraphs.map(paragraph => t(paragraph))}
            bullets={viewModel.taxGuidance.bullets.map(bullet => t(bullet))}
            showAllowanceGuidance={viewModel.taxGuidance.bullets.some(
              bullet => bullet === 'USI_BULLET_ALLOWANCES_1' || bullet === 'USI_BULLET_ALLOWANCES_2'
            )}
          />
        )}

        {viewModel.contactUsMessage && (
          <ContactUsSection message={t(viewModel.contactUsMessage)} linkText={t(viewModel.contactUsLinkText)} linkUrl={viewModel.contactUsLinkUrl} />
        )}
        {viewModel.showTPHigherLayout || viewModel.showTPAdditionalLayout ? null : viewModel.showGenericLayout ? (
          <GenericSavingsInterestDetails savingsInterestThreshold={viewModel.savingsInterestThreshold} />
        ) : (
          <SavingsInterestDetails heading={t(viewModel.details.heading)} savingsInterestThreshold={viewModel.savingsInterestThreshold} />
        )}

        {(viewModel.showTPHigherLayout || viewModel.showGenericLayout || viewModel.showTPAdditionalLayout) && <MoreInformationSection />}
      </div>
    </div>
  );
};

export default withPageTracking(UntaxedSavingsInterestPage);
