import React, { useEffect } from 'react';
import Button from '../../../../components/BaseComponents/Button/Button';
import { useTranslation } from 'react-i18next';
import { StartButton as GDSStartButton } from 'hmrc-gds-react-components';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import { EventType, InteractionTracker } from 'hmrc-odx-features-and-functions';
import { callClientActionDataPage } from '../eventTrackingConfig';
import MainWrapperFull from '../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { formatCurrency, scrollToTop } from '../../../../components/helpers/utils';
import i18next from 'i18next';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import { useNavigate } from 'react-router-dom';

interface UpdateEstimatedTaxableIncomePageProps {
  employerName: string;
  estimatedPay: string;
  tesUrl: string;
  handleNavClick: (e: React.MouseEvent<HTMLAnchorElement>, url: string) => void;
}

const UpdateEstimatedTaxableIncome: React.FC<UpdateEstimatedTaxableIncomePageProps> = ({ employerName, estimatedPay, tesUrl, handleNavClick }) => {
  const navigate = useNavigate();

  const { t } = useTranslation();

  useEffect(() => {
    setPageTitle();
    scrollToTop();
  }, [i18next.language]);

  const handleContinueClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();

    const interactionTracker = new InteractionTracker({
      url: null,
      apiCallback: callClientActionDataPage
    });

    interactionTracker.logEvent(EventType.Outbound, tesUrl, {});

    handleNavClick(e, tesUrl);
  };

  const handleBackClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate(-1);
  };

  return (
    <>
      <Button variant='backlink' onClick={handleBackClick} key='StartPageBacklink' attributes={{ type: 'link' }} />
      <MainWrapperFull title={t('UPDATE_YOUR_ESTIMATED_PAY', { lng: 'en' })}>
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-two-thirds'>
            <h1 className='govuk-heading-l'>{t('UPDATE_YOUR_ESTIMATED_PAY')}</h1>
            <p className='govuk-body-l'>
              {t('OUR_ESTIMATE_OF_INCOME')} {employerName} {t('IS')} {formatCurrency(estimatedPay || 0)}
            </p>

            <p className='govuk-body'>{t('IF_THIS_IS_CORRECT')}</p>
            <p className='govuk-body'>{t('UPDATE_YOUR_ESTIMATE_IF_YOUR_PAY')}</p>
            <p className='govuk-body'>{t('THIS_HELPS_MAKE_SURE')}</p>
            <p className='govuk-body'>{t('IF_YOU_OR_YOUR_PARTNER')}</p>
            <p className='govuk-body'>
              <a
                lang='en'
                className='govuk-link hmrc-report-technical-issue '
                rel='noreferrer noopener'
                target='_blank'
                data-tracking-type='Outbound'
                data-tracking-target='https://www.gov.uk/child-benefit-tax-charge#the-threshold'
                href='https://www.gov.uk/child-benefit-tax-charge#the-threshold'
              >
                {t('CHECK_THIS_HIGH_INCOME')} {t('OPENS_IN_NEW_TAB')}
              </a>
            </p>
            <p className='govuk-body govuk-!-font-weight-bold govuk-!-margin-bottom-6'>{t('IF_YOUR_TAX_CODE_DOES_NOT_CHANGE')}</p>
            <GDSStartButton href='#' onClick={handleContinueClick} text={t('START_NOW')} />
          </div>
        </div>
      </MainWrapperFull>
    </>
  );
};

export default withPageTracking(UpdateEstimatedTaxableIncome);
