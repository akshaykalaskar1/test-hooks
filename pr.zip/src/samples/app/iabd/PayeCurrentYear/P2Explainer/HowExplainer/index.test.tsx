import React from 'react';
import { screen, createEvent, fireEvent } from '@testing-library/react';
import { formatTaxCode } from '../../../../../../components/helpers/utils';
import HowExplainer from '.';
import { PyNote } from '../typings';
import renderWithRouter from '../../../../../../../tests/utils/renderWithRouter';
import PAYE_ROUTES from '../../../../../AppSelector/payeRoutes';
import mockGoTo from '../../../../../../../tests/mocks/routerMocks';

jest.mock('../../../../../../components/helpers/hooks/useCustomNavigate', () => ({
  __esModule: true,
  default: () => mockGoTo
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  formatTaxCode: jest.fn(code => `formatted-${code}`)
}));

const mockTaxDetails: { pyNote: PyNote; AssignedTaxCode: string }[] = [
  { pyNote: 'Before' as PyNote, AssignedTaxCode: '1250L' },
  { pyNote: 'Now' as PyNote, AssignedTaxCode: '1280L' }
];

describe('HowExplainer Component', () => {
  const renderComponent = (overrideProps: Partial<React.ComponentProps<typeof HowExplainer>> = {}) => {
    const props: React.ComponentProps<typeof HowExplainer> = {
      employerName: 'HMRC',
      activeOccupationalPension: false,
      taxDetails: mockTaxDetails,
      monthlyEarnings: 100,
      redirectToViewTimelineDetailsPage: () => {
        throw new Error('Function not implemented.');
      },
      ...overrideProps
    };

    return renderWithRouter(<HowExplainer {...props} />, {
      state: { some: 'state' }
    });
  };

  describe('Given the component is rendered with default props (PAY, monthlyEarnings > 0)', () => {
    beforeEach(() => {
      renderComponent();
    });

    it('Then displays CONTINUE + PAY + INCREASE', () => {
      expect(
        screen.getByText(/YOU_DO_NOT_NEED_TAKE_ACTION WE_WILL_CONTINUE_TO_COLLECT_INCOME_TAX THROUGH_YOUR_PAY AT HMRC AND_INCREASE_TFA/)
      ).toBeInTheDocument();
    });

    it('Then shows the formatted before → now tax code change', () => {
      expect(formatTaxCode).toHaveBeenCalledWith('1250L');
      expect(formatTaxCode).toHaveBeenCalledWith('1280L');

      expect(screen.getByText(/THIS_MEANS_TAX_CODE_WILL_CHANGE_FROM_TO formatted-1250L TO formatted-1280L\./)).toBeInTheDocument();
    });

    it('Then renders a link with the correct label', () => {
      const link = screen.getByRole('link', {
        name: 'CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA'
      });

      expect(link).toBeInTheDocument();
    });
  });

  describe('Given activeOccupationalPension = true (PENSION, monthlyEarnings > 0)', () => {
    it('Then displays THROUGH_YOUR_PENSION + CONTINUE + INCREASE', () => {
      renderComponent({ activeOccupationalPension: true });

      expect(
        screen.getByText(/YOU_DO_NOT_NEED_TAKE_ACTION WE_WILL_CONTINUE_TO_COLLECT_INCOME_TAX THROUGH_YOUR_PENSION AT HMRC AND_INCREASE_TFA/)
      ).toBeInTheDocument();
    });
  });

  describe('Given monthlyEarnings is 0 or null', () => {
    it('When monthlyEarnings = 0 → AUTOMATIC + PAY + REDUCE', () => {
      renderComponent({ monthlyEarnings: 0, activeOccupationalPension: false });

      expect(
        screen.getByText(/YOU_DO_NOT_NEED_TAKE_ACTION WE_WILL_AUTOMATICALLY_COLLECT_TAX THROUGH_YOUR_PAY AT HMRC AND_REDUCE_TFA/)
      ).toBeInTheDocument();
    });

    it('When monthlyEarnings = null & pension active → AUTOMATIC + PENSION + REDUCE', () => {
      renderComponent({ monthlyEarnings: null, activeOccupationalPension: true });

      expect(
        screen.getByText(/YOU_DO_NOT_NEED_TAKE_ACTION WE_WILL_AUTOMATICALLY_COLLECT_TAX THROUGH_YOUR_PENSION AT HMRC AND_REDUCE_TFA/)
      ).toBeInTheDocument();
    });
  });

  describe('Given a different employer name', () => {
    it('Then it uses the provided employer name', () => {
      renderComponent({ employerName: 'Tesco' });

      expect(
        screen.getByText(/YOU_DO_NOT_NEED_TAKE_ACTION WE_WILL_CONTINUE_TO_COLLECT_INCOME_TAX THROUGH_YOUR_PAY AT Tesco AND_INCREASE_TFA/)
      ).toBeInTheDocument();
    });
  });

  describe('Given tax details include Before and Now codes', () => {
    it('Then it correctly finds and formats both tax codes', () => {
      renderComponent();

      expect(formatTaxCode).toHaveBeenCalledWith('1250L');
      expect(formatTaxCode).toHaveBeenCalledWith('1280L');
    });
  });

  describe('Given the link is clicked', () => {
    it('Then prevents default and calls redirect to view timeline details', () => {
      const mockRedirect = jest.fn();

      renderWithRouter(
        <HowExplainer
          employerName='HMRC'
          activeOccupationalPension={false}
          taxDetails={mockTaxDetails}
          monthlyEarnings={200}
          redirectToViewTimelineDetailsPage={mockRedirect}
        />,
        {
          state: { some: 'state' }
        }
      );

      const link = screen.getByRole('link', {
        name: 'CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA'
      });

      const event = createEvent.click(link, { bubbles: true, cancelable: true });
      fireEvent(link, event);

      expect(event.defaultPrevented).toBe(true);
      expect(mockGoTo).toHaveBeenCalledWith(PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS, { some: 'state' });
    });
  });
});
