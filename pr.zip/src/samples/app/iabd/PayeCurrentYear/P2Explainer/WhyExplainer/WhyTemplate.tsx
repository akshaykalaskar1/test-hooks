import { Fragment } from 'react';
import { useTranslation } from 'react-i18next';
import {
  currencyFormatter,
  formatDate,
  GBdate,
  handleTranslation
} from '../../../../../../components/helpers/utils';
import { Segment } from './typings';
import templates from './constant/templateDetails';
import { Link } from 'hmrc-gds-react-components';

function extractDigFromProps(obj: { [s: string]: unknown } | ArrayLike<unknown>) {
  return Object.fromEntries(Object.entries(obj).filter(([k]) => /^DIG_\d+$/.test(k)));
}

function renderSegment(
  content: Segment,
  t: (text: string) => string,
  dig: Record<string, unknown>
): { node: React.ReactNode; text: string } {
  switch (content.type) {
    case 't': {
      const text = t(content.key);
      return { node: text, text };
    }
    case 'currency': {
      const unformattedCurrency = dig[content.prop];
      const text = currencyFormatter(String(unformattedCurrency)) ?? '';
      return { node: text, text };
    }
    case 'number': {
      const text = String(dig[content.prop] ?? '');
      return { node: text, text };
    }
    case 'text': {
      const text = content.value;
      return { node: text, text };
    }
    case 'date': {
      const unformattedDate = dig[content.prop] ?? '';
      const text = formatDate(String(unformattedDate));
      return { node: text, text };
    }
    case 'gbDate': {
      const unformattedDate = dig[content.prop] ?? '';
      const text = GBdate(String(unformattedDate));
      return { node: text, text };
    }
    case 'link': {
      const text = t(content.key);
      return { node: <Link href={content.href}>{text}</Link>, text };
    }
    case 'handleTranslation': {
      const unformattedWord = dig[content.prop];
      const text = handleTranslation(unformattedWord as string);
      return { node: text, text };
    }
    default:
      return { node: null, text: '' };
  }
}

function shouldInsertSpace(prevText: string, nextText: string) {
  if (!prevText || !nextText) return false;

  const nextTrimStart = nextText.trimStart();
  const prevTrimEnd = prevText.trimEnd();

  const leadingPunctuation = [',', '.', ';', ':', '!', '?', '%'];
  const closingBrackets = [')', ']', '}', '»'];
  const openingBrackets = ['(', '[', '{', '«'];

  const nextStartsWithPunct = leadingPunctuation.includes(nextTrimStart[0]);
  const nextStartsWithClose = closingBrackets.includes(nextTrimStart[0]);
  const prevEndsWithOpen = openingBrackets.includes(prevTrimEnd.slice(-1));

  const prevEndsWithSpace = prevText.length > 0 && prevText.endsWith(' ');

  if (nextStartsWithPunct || nextStartsWithClose) return false;
  if (prevEndsWithOpen) return false;

  return !prevEndsWithSpace;
}

export default function WhyTemplate(props) {
  const { t } = useTranslation();
  const { pyActionType, ReferenceID: referenceId } = props;

  if (!referenceId || !pyActionType) return null;

  const componentTemplates = templates[referenceId];
  if (!componentTemplates) return null;

  const selectedParagraphs = componentTemplates[pyActionType];
  if (!selectedParagraphs) return null;

  const dig = extractDigFromProps(props);

  return (
    <>
      {selectedParagraphs.map((para: Segment[]) => {
        const content = para.map(seg => renderSegment(seg, t, dig));
        return (
          <p className='govuk-body' key={`${referenceId}-${pyActionType}-p`}>
            {content.map((contentText, i) => {
              const next = content[i + 1];
              const addSpace = next ? shouldInsertSpace(contentText.text, next.text) : false;
              return (
                <Fragment key={`${referenceId}-${contentText}`}>
                  {contentText.node}
                  {addSpace ? ' ' : null}
                </Fragment>
              );
            })}
          </p>
        );
      })}
    </>
  );
}
