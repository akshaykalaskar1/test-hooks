import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import LoadingWrapper from '../../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import setPageTitle from '../../../../../components/helpers/setPageTitleHelpers';
import i18next from 'i18next';
import { TimeLineEvent } from '../../../../../reuseables/Types/TimeLineEvents';
import P2ExplainerDetails from './P2ExplainerDetails';
import type { ExplainerData } from './typings';
import ErrorMessage from '../../ErrorPage/errorMessage';
import PAYE_ROUTES from '../../../../AppSelector/payeRoutes';

interface P2TaxCodeChangeProps {
  redirectCurrentYearPage: () => void;
  redirecLatestEventPage: (s: string) => void;
  redirectToViewTimelineDetailsPage: () => void;
  eventType: string;
}

export default function P2TaxCodeChange({
  redirectCurrentYearPage,
  redirecLatestEventPage,
  redirectToViewTimelineDetailsPage,
  eventType
}: P2TaxCodeChangeProps) {
  const { taxCodeIdentifier } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [fetchedData, setFetchedData] = useState<ExplainerData | null>(null);
  const [errorMsgArr, setErrorMsgArr] = useState<string[]>([]);
  const [hasFetched, setHasFetched] = useState(false);

  // write some logic here to remove dynamic taxCodeIdentifier from URL and modify the urkl and pass it to

  useEffect(() => {
    setPageTitle();
  }, [i18next.language]);

  useEffect(() => {
    if (taxCodeIdentifier) {
      navigate(PAYE_ROUTES.ALLOWED_PARAMETERISED_ROUTES.P2_TAX_CODE_CHANGE, {
        replace: true,
        state: {
          taxCodeIdentifier
        }
      });
    }
  }, [taxCodeIdentifier, navigate]);

  useEffect(() => {
    if (hasFetched) return;

    setHasFetched(true);
    setIsPageLoading(true);
    setErrorMsgArr([]);
    setFetchedData(null);

    const parameters = {
      taxCodeIdentifier: Number(taxCodeIdentifier)
    };

    const fetchData = async () => {
      try {
        const response = await PCore.getDataPageUtils().getDataAsync('D_P2Digital', 'root', parameters, {}, {}, { invalidateCache: true });

        const data = response?.data?.[0];
        const errorMsg = data?.pyErrors?.pyMessages?.[0]?.pyErrorMessage;

        if (Array.isArray(errorMsg) && errorMsg.length > 0) {
          setErrorMsgArr(errorMsg);
        } else {
          const taxSummary = data?.Customer?.TaxSummaryList?.[0] ?? null;
          setFetchedData(taxSummary);
        }
      } catch {
        setErrorMsgArr(['ERROR']);
        console.log('Error: D_P2Explainer failed');
      } finally {
        setIsPageLoading(false);
      }
    };

    fetchData();
  }, [taxCodeIdentifier, hasFetched]);

  return (
    <LoadingWrapper pageIsLoading={isPageLoading} spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}>
      {errorMsgArr.length > 0 ? (
        <ErrorMessage />
      ) : (
        // <P2ExplainerDetails
        //   redirecLatestEventPage={redirecLatestEventPage}
        //   redirectCurrentYearPage={redirectCurrentYearPage}
        //   redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
        //   timelineDetails={timelineDetails}
        //   eventType={eventType}
        //   explainerData={fetchedData}
        //   pageName={fetchedData?.pyTemplateDataField}
        // />

        <>{taxCodeIdentifier}</>
      )}
    </LoadingWrapper>
  );
}
