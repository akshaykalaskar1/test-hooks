import React from 'react';
import { formatDate, generateKey, getCurrentLang, getTaxCodeForTimeline, getHeadingContent } from '../../../../components/helpers/utils';
import { TimeLineEvent, TimeLineEvents } from '../../../../reuseables/Types/TimeLineEvents';
import { useTranslation } from 'react-i18next';
import RenderTimeLineEventHeading from './RenderTimeLineEventHeading';

interface CurrentYearTimeLineProps {
  latestTimeLineEvents: TimeLineEvents;
  eventType: string;
  handleViewDetailsClick: (d: TimeLineEvent, s: string) => void;
}
const CurrentTimeLineEvent = (props: CurrentYearTimeLineProps) => {
  const { latestTimeLineEvents, eventType, handleViewDetailsClick } = props;
  const { t } = useTranslation();
  const lang = getCurrentLang();
  const isShortEvent = eventType === 'event';
  const currentTimeLineEvents = isShortEvent ? latestTimeLineEvents?.slice(0, 3) : latestTimeLineEvents;
  const getHelperText = (templateType: string) => {
    const type = templateType.toUpperCase();
    return type === 'TAXCODE' ? t('OFF') : type === 'P2TAXCODE' || type === 'P2' ? t('OFF_WHY') : t('OFF_THE');
  };
  const getTimeLineEvents = () => {
    return currentTimeLineEvents?.map((currentEvent, index) => (
      <li className='hmrc-timeline__event' key={generateKey(currentEvent?.Content[0]?.pyKeyString, index, 'fullEvent')}>
        <RenderTimeLineEventHeading isShortEvent={isShortEvent}>
          {getHeadingContent(currentEvent?.Content, lang)?.Description}
        </RenderTimeLineEventHeading>

        {currentEvent?.DisplayDate && (
          <time className='hmrc-timeline__event-meta' dateTime={currentEvent.DisplayDate}>
            {formatDate(currentEvent.DisplayDate)}
          </time>
        )}
        {getTaxCodeForTimeline(currentEvent?.issuedtaxCode) && (
          <div className='hmrc-timeline__event-content'>
            <p className='govuk-body'>{getTaxCodeForTimeline(currentEvent.issuedtaxCode)}</p>
          </div>
        )}
        {currentEvent?.pyTemplateDataField && (
          <div className='hmrc-timeline__event-content'>
            <p className='govuk-body'>
              <a
                href='#'
                className='govuk-link'
                onClick={e => {
                  e.preventDefault();
                  handleViewDetailsClick(currentEvent, eventType);
                }}
              >
                {t('VIEW_DETAILS')}
                <span className='govuk-visually-hidden'>
                  {`${getHelperText(currentEvent.pyTemplateDataField)} ${getHeadingContent(currentEvent?.Content, lang)?.Description} ${t('ON')} ${formatDate(currentEvent.DisplayDate)}`}
                </span>
              </a>
            </p>
          </div>
        )}
      </li>
    ));
  };

  return <>{getTimeLineEvents()}</>;
};

export default CurrentTimeLineEvent;
