import React, { Dispatch, SetStateAction, useEffect, useState } from 'react';

import { useTranslation } from 'react-i18next';
import Button from '../../../../components/BaseComponents/Button/Button';
import MainWrapperFull from '../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import TaxFreeAmountDetails from './TaxFreeAmountDetails';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import i18next from 'i18next';
import { formatCurrency, formatDate, getCurrentLang, getHeadingContent, scrollToTop, formatTaxCode } from '../../../../components/helpers/utils';
import { TimeLineEvent } from '../../../../reuseables/Types/TimeLineEvents';
import ErrorMessage from '../ErrorPage/errorMessage';
import { WIMTCDetails } from './PayeCurrentYearTypes';
import TaxCodeExplainer from './TaxCodeExplainer';
import TaxFreeAmountTable from './TaxFreeAmountTable';
import CategoryD7 from './CatDPages/CategoryD7';
import CategoryD6 from './CatDPages/CategoryD6';
import CategoryD5 from './CatDPages/CategoryD5';
import CategoryD4 from './CatDPages/CategoryD4';
import CategoryD3 from './CatDPages/CategoryD3';
import CategoryD2 from './CatDPages/CategoryD2';
import CategoryD1 from './CatDPages/CategoryD1';
import CategoryD8 from './CatDPages/CategoryD8';
import CategoryD9 from './CatDPages/CategoryD9';
import CategoryD10 from './CatDPages/CategoryD10';
import CategoryC1 from './CatCpages/CategoryC1';
import CategoryC from './CatCpages/CategoryC';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import LoadingWrapper from '../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import { useNavigate } from 'react-router-dom';

interface ViewTimelineDetailsProps {
  timelineDetails: TimeLineEvent;
  redirectCurrentYearPage: () => void;
  redirecLatestEventPage: (s: string) => void;
  eventType: string;
  comingFromPage: string;
  setComingFromPage: Dispatch<SetStateAction<string>>;
  handleLinkClick: (d: string) => void;
  redirectToAllIABDLandingPage: (d: string) => void;
  handleDetailExplainerLinkClick: (e, h: string) => void;
  redirectToDeductionExplainerpage: (comingFrom: string, explainerPage: string, SourceAmount: string) => void;
}

const ViewTimelineDetails = ({
  timelineDetails,
  handleLinkClick,
  redirectToAllIABDLandingPage,
  handleDetailExplainerLinkClick,
  redirectToDeductionExplainerpage,
  setComingFromPage
}: ViewTimelineDetailsProps) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [errorMsgArr, setErrorMsgArr] = useState([]);
  const [taxSummaryList, setTaxSummaryList] = useState(null);

  const { t } = useTranslation();
  const lang = getCurrentLang();

  const templateType: string = timelineDetails?.pyTemplateDataField?.toLocaleLowerCase();
  const isActivePension: boolean = timelineDetails?.ActiveOccupationalPension;
  const isPrimaryEmployment: boolean = timelineDetails?.EmploymentType?.toUpperCase() === 'PRIMARY';

  useEffect(() => {
    setPageTitle();
    scrollToTop();
  }, [i18next.language]);

  async function fetchWIMTCDetails() {
    const parameters = {
      issuedtaxCode: timelineDetails?.issuedtaxCode,
      NetCodedAllowance: timelineDetails?.NetCodedAllowance,
      taxCodeIdentifier: timelineDetails?.IntegerSortingHolder,
      EmploymentRecordType: timelineDetails?.EmploymentType,
      ESN: timelineDetails?.EmploymentSequenceNumber
    };

    try {
      const res = await PCore.getDataPageUtils().getDataAsync('D_WIMTC', 'root', parameters, {}, {}, { invalidateCache: true });
      return res;
    } catch (error) {
      console.error('Error fetching D_WIMTC data:', error);
      return null;
    }
  }

  async function fetchTaxCodeData() {
    setIsLoading(true);
    try {
      const details: WIMTCDetails = await fetchWIMTCDetails();
      setTaxSummaryList(details?.data?.[0]?.Customer?.TaxSummaryList[0]);
      const errorMsg = details?.data?.[0]?.pyErrors?.pyMessages?.[0]?.pyErrorMessage ?? [];
      if (errorMsg) setErrorMsgArr(errorMsg);
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (templateType === 'p2taxcode' || templateType === 'taxcode') {
      fetchTaxCodeData();
    } else {
      setIsLoading(false);
    }
  }, []);

  function renderCategoryAContent(changeType: string): React.ReactNode {
    switch (changeType) {
      case 'increase':
        return (
          <>
            <p className='govuk-body'>{t('EXPLAINER_CAT_A_BODY_INC')}</p>
            <p className='govuk-body'>{t('EXPLAINER_CAT_A_BODY')}</p>
            <p className='govuk-body'>{t('YOU_DO_NOT_DO_ANYTHING')}</p>
          </>
        );
      case 'decrease':
        return (
          <>
            <p className='govuk-body'>{t('EXPLAINER_CAT_A_BODY_DEC')}</p>
            <p className='govuk-body'>{t('EXPLAINER_CAT_A_BODY')}</p>
            <p className='govuk-body'>{t('YOU_DO_NOT_DO_ANYTHING')}</p>
          </>
        );
      default:
        return null;
    }
  }

  function renderBody(pyTemplateDataField: string): React.ReactNode {
    let templeteBody;
    const [category, changeType] = pyTemplateDataField?.includes('-') ? pyTemplateDataField.split('-') : [pyTemplateDataField, undefined];
    switch (category) {
      case 'c':
        templeteBody = <CategoryC />;
        break;
      case 'c1':
        templeteBody = <CategoryC1 />;
        break;
      case 'a':
        templeteBody = renderCategoryAContent(changeType);
        break;
      case 'd2':
        templeteBody = <CategoryD2 />;
        break;
      case 'd3':
        templeteBody = <CategoryD3 />;
        break;
      case 'd4':
        templeteBody = <CategoryD4 />;
        break;
      case 'd5':
        templeteBody = <CategoryD5 />;
        break;
      case 'd6':
        templeteBody = <CategoryD6 />;
        break;
      case 'd7':
        templeteBody = <CategoryD7 />;
        break;
      case 'd8':
        templeteBody = <CategoryD8 handleDetailExplainerLinkClick={handleDetailExplainerLinkClick} />;
        break;
      case 'd9':
        templeteBody = <CategoryD9 handleDetailExplainerLinkClick={handleDetailExplainerLinkClick} />;
        break;
      case 'd1':
        templeteBody = <CategoryD1 handleDetailExplainerLinkClick={handleDetailExplainerLinkClick} dataType={changeType} />;
        break;
      case 'd10':
        templeteBody = <CategoryD10 />;
        break;
      default:
        break;
    }
    return templeteBody;
  }

  const renderTemplateForTaxCode = () => {
    return (
      <>
        <p className='govuk-body'>
          {t('WE_HAVE_SENT')} {isActivePension ? t('PENSION_PROVIDER') : t('EMPLOYER')}.
        </p>
        <p className='govuk-body'>
          {t('THIS_MAY_AFFECT')} {isActivePension ? t('PENSION_PROVIDER') : t('EMPLOYER')} {t('STARTS_TO_USE_TAX')}
        </p>
        <TaxFreeAmountDetails
          allowances={taxSummaryList?.CurrentAllowanceList}
          personalAllowances={taxSummaryList?.PersonalAllowances}
          deductions={taxSummaryList?.CurrentDeductionsList}
          handleLinkClick={handleLinkClick}
          redirectToDeductionExplainerpage={redirectToDeductionExplainerpage}
          comingFrom='viewTimelineDetailsPage'
        />
        <p className='govuk-body'>
          {isActivePension ? t('YOUR_TAX_FREE_AMOUNT_PENSION') : t('YOUR_TAX_FREE_AMOUNT_EMPLOYMENT')}
          {timelineDetails?.NetCodedAllowance && formatCurrency(timelineDetails?.NetCodedAllowance, true)}.
        </p>
        {isPrimaryEmployment && (
          <p className='govuk-body'>
            {t('IF_YOU_THINK_INCORRECT')}
            <a
              className='govuk-link'
              href='#'
              onClick={e => {
                e.preventDefault();
                redirectToAllIABDLandingPage('ViewTimelineDetailsPage');
                setComingFromPage('ViewTimelineDetailsPage');
              }}
            >
              {t('UPDATE_REMOVE_INFO_ABOUT_YOU')}
            </a>
            .
          </p>
        )}
        <TaxFreeAmountTable taxDetails={taxSummaryList?.TaxDetails} />
        {taxSummaryList?.TaxAttribute && (
          <TaxCodeExplainer
            taxCode={taxSummaryList?.TaxAttribute}
            netCodedAllowance={timelineDetails?.NetCodedAllowance}
            isActivePension={isActivePension}
            issuedTaxCode={timelineDetails?.issuedtaxCode}
          />
        )}

        <h2 className='govuk-heading-m govuk-!-margin-top-7'>{t('WHAT_HAPPEN_NEXT')}</h2>
        <p className='govuk-body'>{t('THIS_IS_FOR_YOUR_INFO')}</p>
      </>
    );
  };

  function decideHeading() {
    // pyCategory: "IABDEvent" - show Iabd explainer otherwise WIMTC
    return timelineDetails?.pyCategory === 'IABDEvent' ? (
      <>{getHeadingContent(timelineDetails?.Content, lang)?.Description}</>
    ) : (
      <>
        {t('YOUR_UPDATED_TAX_CODE_FOR')} {timelineDetails?.EmployerName} {t('IS')} {formatTaxCode(timelineDetails?.issuedtaxCode)}
      </>
    );
  }

  return (
    <LoadingWrapper pageIsLoading={isLoading} spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}>
      <>
        <Button
          variant='backlink'
          onClick={e => {
            e.preventDefault();
            navigate(-1);
          }}
          key='ViewTimelineBacklink'
          attributes={{ type: 'link' }}
        />
        <>
          {errorMsgArr?.length > 0 && <ErrorMessage />}
          {errorMsgArr?.length === 0 && (
            <MainWrapperFull title={getHeadingContent(timelineDetails?.Content, 'en')?.Description}>
              <div className='govuk-grid-row'>
                <div className='govuk-grid-column-two-thirds'>
                  <h1 className='govuk-heading-l'>{decideHeading()}</h1>
                  <p className='govuk-hint'>{formatDate(timelineDetails?.DisplayDate)}</p>
                  {renderBody(timelineDetails?.pyTemplateDataField?.toLocaleLowerCase())}
                  {(templateType === 'p2taxcode' || templateType === 'taxcode') && renderTemplateForTaxCode()}
                </div>
              </div>
            </MainWrapperFull>
          )}
        </>
      </>
    </LoadingWrapper>
  );
};

export default withPageTracking(ViewTimelineDetails);
