import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';

import AllIABDLanding from './AllIABDLanding';
import { AllIABDDetails } from '../PayeCurrentYearTypes';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn().mockResolvedValue({
    serverConfig: {
      sdkContentServerUrl: 'http://mock-content-server',
      sdkHmrcURL: 'http://mock-hmrc-url'
    }
  }),
  logout: jest.fn()
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: any) => Component
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate
}));

jest.mock('./ALLIABDPageHeader', () => (props: any) => <div data-testid='mock-header'>header-{String(props.isDetailsAvailable)}</div>);

jest.mock('./AllIABDBody', () => (props: any) => {
  if (!props.isDetailsAvailable) return null;
  return <div data-testid='mock-body'>body</div>;
});

jest.mock('../../ErrorPage/errorMessage', () => () => <div>ERROR</div>);

const mockGetDataAsync = jest.fn();

(globalThis as any).PCore = {
  getDataPageUtils: () => ({
    getPageDataAsync: mockGetDataAsync
  })
};

const baseProps = {
  comingFromPage: '',
  handleLinkClick: jest.fn(),
  handleMoreInformationClick: jest.fn()
};

describe('AllIABDLanding (BDD)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Given page is loading', () => {
    test('Then loading spinner is shown', () => {
      mockGetDataAsync.mockReturnValue(new Promise(() => {}));

      render(<AllIABDLanding {...baseProps} />);

      expect(screen.getByText('LOADING')).toBeInTheDocument();
    });
  });

  describe('Given API returns empty data', () => {
    test('Then header shows empty state and body is not rendered', async () => {
      const mockResponse: AllIABDDetails = {
        Customer: {
          TaxSummaryList: [
            {
              CurrentBenefitsList: [],
              CurrentIncomeList: [],
              CurrentAllowanceList: [],
              CurrentDeductionsList: []
            }
          ]
        }
      };

      mockGetDataAsync.mockResolvedValue(mockResponse);

      render(<AllIABDLanding {...baseProps} />);

      expect(screen.queryByTestId('mock-body')).not.toBeInTheDocument();
    });
  });

  describe('Given API returns error structure', () => {
    test('Then error component is displayed', async () => {
      mockGetDataAsync.mockResolvedValue({
        pyErrors: {
          pyMessages: [
            {
              pyErrorMessage: ['error']
            }
          ]
        }
      });

      render(<AllIABDLanding {...baseProps} />);

      expect(await screen.findByText('ERROR')).toBeInTheDocument();
    });
  });

  describe('Given API throws exception', () => {
    test('Then fallback error is shown', async () => {
      mockGetDataAsync.mockRejectedValue(new Error('fail'));

      render(<AllIABDLanding {...baseProps} />);

      expect(await screen.findByText('ERROR')).toBeInTheDocument();
    });
  });

  describe('Given user clicks back button', () => {
    test('When comingFromPage exists Then navigate back', async () => {
      mockGetDataAsync.mockResolvedValue({
        Customer: {
          TaxSummaryList: [
            {
              CurrentBenefitsList: [],
              CurrentIncomeList: [],
              CurrentAllowanceList: [],
              CurrentDeductionsList: []
            }
          ]
        }
      });

      render(<AllIABDLanding {...baseProps} comingFromPage='test' />);

      const backBtn = await screen.findByText('BACK');

      fireEvent.click(backBtn);

      expect(mockNavigate).toHaveBeenCalledWith(-1);
    });
  });
});
