import React from 'react';
import { Heading, SummaryList, SummaryListRow } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';

import { getIABDTableMetaConfig } from './config/iabdTableMetaCofig';
import { formatCurrency } from '../../../../../components/helpers/utils';
import { getContentOnLanguageSelection, getKey, getEmploymentName } from '../../../../../components/helpers/AllIABDLanding/AllIABDLandingUtils';
import { IABDType } from './config/iabdTypes';
import { EventType, InteractionTracker } from 'hmrc-odx-features-and-functions';
import { callClientActionDataPage } from '../../eventTrackingConfig';

interface AllIABDTableProps {
  type: IABDType;
  list: any[];
  handleLinkClick: (url: string) => void;
  handleMoreInformationClick?: (val: string) => void;
}

const AllIABDTable: React.FC<AllIABDTableProps> = ({ type, list, handleLinkClick, handleMoreInformationClick }) => {
  const { t } = useTranslation();

  const config = getIABDTableMetaConfig(t)[type];

  const handleAnchorClick = async (e: React.MouseEvent, url?: string, isInternalRedirect: boolean = false) => {
    e.preventDefault();

    if (isInternalRedirect) {
      handleMoreInformationClick?.(url);
      return;
    } else {
      const interactionTracker = new InteractionTracker({
        url: null,
        apiCallback: callClientActionDataPage
      });

      await interactionTracker.logEvent(EventType.Outbound, `${url}`, {});
      handleLinkClick(url);
    }
  };

  const renderLink = (item: any) => {
    const tesLink = item?.TESLinks?.[0];
    if (!tesLink) return undefined;

    const content = getContentOnLanguageSelection(tesLink?.Content);

    if (!content?.Name) return undefined;

    return (
      <a href='#' className='govuk-link' onClick={e => handleAnchorClick(e, content?.pyURLContent, content?.IsInternalRedirect)}>
        {content?.Name}
        <span className='govuk-visually-hidden'>{content?.HiddenText}</span>
      </a>
    );
  };

  const renderLabel = (item: any) => {
    const name = getContentOnLanguageSelection(item?.Content)?.Name;

    if (!config.showEmployment) return name;

    const employment = getEmploymentName(item?.EmploymentName);

    return (
      <>
        {name}
        {!!employment && <span className='govuk-!-display-block govuk-!-font-weight-regular'>{employment}</span>}
      </>
    );
  };

  if (!list?.length) {
    return (
      <>
        <Heading headingLevel={2} className='govuk-heading-m'>
          {config.title}
        </Heading>
        <p className='govuk-body'>{config.emptyText}</p>
      </>
    );
  }

  return (
    <>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {config.title}
      </Heading>

      <SummaryList>
        {list.map(item => (
          <SummaryListRow
            key={getKey(item)}
            label={renderLabel(item)}
            value={formatCurrency(item?.Amount)}
            classes={{ key: 'govuk-!-width-one-half' }}
            actions={renderLink(item)}
          />
        ))}
      </SummaryList>
    </>
  );
};

export default AllIABDTable;
