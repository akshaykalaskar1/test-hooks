import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import MissingDetailLinksSection from './MissingDetailsSection';
import { appendLangParam } from '../../../../../components/helpers/utils';
import { InteractionTracker, EventType } from 'hmrc-odx-features-and-functions';

const mockAssign = jest.fn();

jest.mock('../../../../../components/helpers/hooks/HMRCExternalLinks', () => ({
  __esModule: true,
  default: () => ({
    hmrcQAURL: 'https://qa.tax.service.gov.uk/'
  })
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../components/helpers/utils', () => ({
  appendLangParam: jest.fn(url => url)
}));

jest.mock('hmrc-odx-features-and-functions');

describe('MissingDetailLinksSection', () => {
  const mockLogEvent = jest.fn().mockResolvedValue(undefined);

  const expectedAllowanceUrl = 'https://qa.tax.service.gov.uk/submissions/new-form/tell-hmrc-about-your-tax-free-allowance';

  beforeEach(() => {
    jest.clearAllMocks();

    Object.defineProperty(window, 'location', {
      writable: true,
      value: {
        assign: mockAssign
      }
    });

    (InteractionTracker as jest.Mock).mockImplementation(() => ({
      logEvent: mockLogEvent
    }));
  });

  describe('Given the component is rendered', () => {
    test('Then all missing detail links should be displayed', () => {
      render(<MissingDetailLinksSection />);

      expect(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_LINK'
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_INVESTMENT_INCOME_LINK'
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_COMPANY_BENEFIT_LINK'
        })
      ).toBeInTheDocument();

      expect(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_EXTERNAL_LINK'
        })
      ).toBeInTheDocument();
    });

    test('Then allowance link should contain the correct href', () => {
      render(<MissingDetailLinksSection />);

      const link = screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
      });

      expect(link).toHaveAttribute('href', expectedAllowanceUrl);
    });
  });

  describe('Given the user clicks the allowance link', () => {
    test('When tracking succeeds Then an outbound event should be logged and navigation should occur', async () => {
      render(<MissingDetailLinksSection />);

      const link = screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
      });

      fireEvent.click(link);

      await waitFor(() => {
        expect(mockLogEvent).toHaveBeenCalledWith(EventType.Outbound, '/submissions/new-form/tell-hmrc-about-your-tax-free-allowance', {});
      });

      expect(mockAssign).toHaveBeenCalledWith(expectedAllowanceUrl);
    });

    test('Then InteractionTracker should be created', async () => {
      render(<MissingDetailLinksSection />);

      fireEvent.click(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
        })
      );

      await waitFor(() => {
        expect(InteractionTracker).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Given tracking has not yet resolved', () => {
    test('When the user clicks a link Then navigation should wait for tracking completion', async () => {
      let resolvePromise!: () => void;

      const pendingPromise = new Promise<void>(resolve => {
        resolvePromise = resolve;
      });

      mockLogEvent.mockReturnValueOnce(pendingPromise);

      render(<MissingDetailLinksSection />);

      fireEvent.click(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
        })
      );

      expect(mockAssign).not.toHaveBeenCalled();

      resolvePromise();

      await waitFor(() => {
        expect(mockAssign).toHaveBeenCalledWith(expectedAllowanceUrl);
      });
    });
  });

  describe('Given tracking is shuttered', () => {
    test('When logEvent never resolves Then navigation should not occur', () => {
      mockLogEvent.mockReturnValueOnce(new Promise(() => {}));

      render(<MissingDetailLinksSection />);

      fireEvent.click(
        screen.getByRole('link', {
          name: 'MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK'
        })
      );

      expect(mockAssign).not.toHaveBeenCalled();
    });
  });

  test('When pension relief link is clicked Then tracking and navigation should occur', async () => {
    render(<MissingDetailLinksSection />);

    fireEvent.click(
      screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_EXTERNAL_LINK'
      })
    );

    await waitFor(() => {
      expect(mockLogEvent).toHaveBeenCalledWith(EventType.Outbound, '/submissions/new-form/claim-personal-pension-tax-relief', {});
    });

    expect(mockAssign.mock.calls[0][0]).toContain('claim-personal-pension-tax-relief');
  });

  test('When income link is clicked Then tracking should occur', async () => {
    render(<MissingDetailLinksSection />);

    fireEvent.click(
      screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_LINK'
      })
    );

    await waitFor(() =>
      expect(mockLogEvent).toHaveBeenCalledWith(EventType.Outbound, '/digital-forms/form/tell-us-about-other-income/draft/guide', {})
    );
  });

  test('When investment income link is clicked Then tracking should occur', async () => {
    render(<MissingDetailLinksSection />);

    fireEvent.click(
      screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_INVESTMENT_INCOME_LINK'
      })
    );

    await waitFor(() =>
      expect(mockLogEvent).toHaveBeenCalledWith(EventType.Outbound, '/submissions/new-form/tell-hmrc-about-your-investment-income/', {})
    );
  });

  test('When company benefit link is clicked Then tracking should occur', async () => {
    render(<MissingDetailLinksSection />);

    fireEvent.click(
      screen.getByRole('link', {
        name: 'MISSING_DETAILS_LINKS.ADD_COMPANY_BENEFIT_LINK'
      })
    );

    await waitFor(() =>
      expect(mockLogEvent).toHaveBeenCalledWith(EventType.Outbound, '/submissions/new-form/tell-hmrc-about-your-company-benefits/', {})
    );
  });
});
