export const IABD_TYPES = {
  BENEFITS: 'benefits',
  INCOMES: 'incomes',
  ALLOWANCES: 'allowances',
  DEDUCTIONS: 'deductions'
} as const;

export type IABDType = (typeof IABD_TYPES)[keyof typeof IABD_TYPES];
