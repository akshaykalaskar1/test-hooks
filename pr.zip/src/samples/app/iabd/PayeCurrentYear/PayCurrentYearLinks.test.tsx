import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import PayeCurrentYearLinks from './PayCurrentYearLinks';

const mockHandleLinkClick = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

describe('PayeCurrentYearLinks', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the component is rendered, when loaded, then the further actions heading is displayed', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    expect(screen.getByText('FURTHER_ACTIONS')).toBeInTheDocument();
  });

  test('Given the component is rendered, when loaded, then employee expenses link is displayed', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    expect(screen.getByText('CHECK_IF_YOU_CAN_CLAIM_EMPLOYEE_EXPENSES')).toBeInTheDocument();
  });

  test('Given the component is rendered, when loaded, then other income link is displayed', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    expect(screen.getByText('ADD_A_MISSING_INCOME_FROM_ANOTHER_SOURCE')).toBeInTheDocument();
  });

  test('Given the component is rendered, when loaded, then investment income link is displayed', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    expect(screen.getByText('ADD_INVESTMENT_INCOME')).toBeInTheDocument();
  });

  test('Given employee expenses link is clicked, when selected, then employee expenses path is passed to the handler', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    fireEvent.click(screen.getByText('CHECK_IF_YOU_CAN_CLAIM_EMPLOYEE_EXPENSES'));

    expect(mockHandleLinkClick).toHaveBeenCalledWith('/tax-relief-for-employees');
  });

  test('Given missing income link is clicked, when selected, then other income path is passed to the handler', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    fireEvent.click(screen.getByText('ADD_A_MISSING_INCOME_FROM_ANOTHER_SOURCE'));

    expect(mockHandleLinkClick).toHaveBeenCalledWith('/digital-forms/form/tell-us-about-other-income/draft/guide');
  });

  test('Given investment income link is clicked, when selected, then investment income path is passed to the handler', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    fireEvent.click(screen.getByText('ADD_INVESTMENT_INCOME'));

    expect(mockHandleLinkClick).toHaveBeenCalledWith('/digital-forms/form/tell-us-about-investment-income/draft/guide');
  });

  test('Given the links are rendered, when inspected, then tracking attributes are present', () => {
    render(<PayeCurrentYearLinks handleLinkClick={mockHandleLinkClick} />);

    const links = screen.getAllByRole('link');

    links.forEach(link => {
      expect(link).toHaveAttribute('data-tracking-type', 'Outbound');
    });
  });
});
