import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import CurrentYearTimeLine from './payCurrentYearTimeline';

const mockRedirecLatestEventPage = jest.fn();
const mockHandleViewDetailsClick = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('./CurrentTimeLineEvent', () => ({
  __esModule: true,
  default: ({ latestTimeLineEvents, eventType }: any) => (
    <div data-testid='current-timeline-event'>
      {eventType}-{latestTimeLineEvents.length}
    </div>
  )
}));

describe('CurrentYearTimeLine', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the component is rendered, when timeline events exist, then the heading and timeline are displayed', () => {
    const events = [{ id: 1 }];

    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={events as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.getByText('LATEST_ACTIVITY')).toBeInTheDocument();
  });

  test('Given timeline events exist, when rendered, then CurrentTimeLineEvent receives the events', () => {
    const events = [{ id: 1 }, { id: 2 }];

    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={events as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.getByText('event-2')).toBeInTheDocument();
  });

  test('Given more than three timeline events exist, when rendered, then the View All Activity link is displayed', () => {
    const events = [{}, {}, {}, {}];

    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={events as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.getByText('VIEW_ALL_ACTIVITY')).toBeInTheDocument();
  });

  test('Given more than three timeline events exist, when View All Activity is clicked, then the latest events page is opened', () => {
    const events = [{}, {}, {}, {}];

    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={events as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    fireEvent.click(screen.getByText('VIEW_ALL_ACTIVITY'));

    expect(mockRedirecLatestEventPage).toHaveBeenCalledWith('PayeCurrentYearPage');
  });

  test('Given three or fewer timeline events exist, when rendered, then the View All Activity link is not displayed', () => {
    const events = [{}, {}, {}];

    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={events as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.queryByText('VIEW_ALL_ACTIVITY')).not.toBeInTheDocument();
  });

  test('Given no timeline events exist, when rendered, then the no activity message is displayed', () => {
    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={[]}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.getByText('NO_ACTIVITY_YET')).toBeInTheDocument();
  });

  test('Given timeline events are undefined, when rendered, then the no activity message is displayed', () => {
    render(
      <CurrentYearTimeLine
        latestTimeLineEvents={undefined as any}
        redirecLatestEventPage={mockRedirecLatestEventPage}
        handleViewDetailsClick={mockHandleViewDetailsClick}
      />
    );

    expect(screen.getByText('NO_ACTIVITY_YET')).toBeInTheDocument();
  });
});
