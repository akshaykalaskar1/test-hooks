import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import { scrollToTop } from '../../../../components/helpers/utils';
import WinterFuelExplainerPage from './WinterFuelExplainerPage';

const mockNavigate = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('i18next', () => ({
  language: 'en'
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('../../../../components/helpers/utils', () => ({
  appendLangParam: (url: string) => url,
  formatCurrency: (value: number) => `£${value.toLocaleString()}`,
  scrollToTop: jest.fn()
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ children, onClick, variant }: any) => <button onClick={onClick}>{children || (variant === 'backlink' ? 'Back' : '')}</button>
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  withPageTracking: (Component: any) => Component
}));

describe('WinterFuelExplainerPage', () => {
  const props = {
    redirectToAllIABDLandingPage: jest.fn(),
    incomeThresholdForWinterFuelPayment: 35000
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    render(<WinterFuelExplainerPage {...props} />);

    expect(screen.getByText('WINTER_FUEL_PAYMENT_OR_PENSION_AGE_WINTER_HEATING_PAYMENT')).toBeInTheDocument();

    expect(screen.getByText('THE_WINTER_FUEL_PAYMENT_IS_A_YEARLY_PAYMENT')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the external guidance link is displayed', () => {
    render(<WinterFuelExplainerPage {...props} />);

    const link = screen.getByRole('link');

    expect(link).toBeInTheDocument();

    expect(link).toHaveTextContent('FIND_OUT_MORE OPENS_IN_NEW_TAB');

    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noreferrer noopener');
  });

  test('Given the page is rendered, when the backlink is clicked, then the user is navigated back', () => {
    render(<WinterFuelExplainerPage {...props} />);

    fireEvent.click(screen.getByText('Back'));

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  test('Given the page is rendered, when loaded, then page title and scroll behaviour are triggered', () => {
    render(<WinterFuelExplainerPage {...props} />);

    expect(setPageTitle).toHaveBeenCalled();
    expect(scrollToTop).toHaveBeenCalled();
  });

  test('Given the page is rendered, when loaded, then all section headings are displayed', () => {
    render(<WinterFuelExplainerPage {...props} />);

    expect(screen.getByText('HOW_IT_COULD_AFFECT_YOUR_TAX')).toBeInTheDocument();

    expect(screen.getByText('IF_SELF_ASSESSMENT')).toBeInTheDocument();

    expect(screen.getByText('IF_YOU_LIVE_IN_SCOTLAND_REPEAT')).toBeInTheDocument();
  });
});
