import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import InterruptionPage from './InterruptionPage';

const mockNavigate = jest.fn();
const mockLogEvent = jest.fn();

jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  withPageTracking: (Component: any) => Component,
  EventType: {
    Outbound: 'Outbound'
  },
  InteractionTracker: jest.fn().mockImplementation(() => ({
    logEvent: jest.fn()
  }))
}));

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('i18next', () => ({
  language: 'en'
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => jest.fn());

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ children, onClick, variant }: any) => <button onClick={onClick}>{children || (variant === 'backlink' ? 'Back' : '')}</button>
}));

describe('InterruptionPage', () => {
  const props = {
    employmentSequenceNumber: 123,
    handleNavClick: jest.fn()
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    render(<InterruptionPage {...props} />);

    expect(screen.getByText('UPDATE_ESTIMATED_PAY')).toBeInTheDocument();

    expect(screen.getByText('IN_THE_VAST_MAJORITY_OF_CASES_YOUR_TAX_CODE')).toBeInTheDocument();

    expect(screen.getByText('YES')).toBeInTheDocument();
    expect(screen.getByText('NO')).toBeInTheDocument();
  });

  test('Given no option is selected, when continue is clicked, then an error is displayed', () => {
    render(<InterruptionPage {...props} />);

    fireEvent.click(screen.getByText('CONTINUE'));

    expect(screen.getByText('THERE_IS_A_PROBLEM')).toBeInTheDocument();

    expect(screen.getAllByText('SELECT_YES_IF_YOU_WANT_TO_UPDATE')[0]).toBeInTheDocument();
  });

  test('Given yes is selected, when continue is clicked, then navigation is triggered', () => {
    render(<InterruptionPage {...props} />);

    fireEvent.click(screen.getByLabelText('YES'));
    fireEvent.click(screen.getByText('CONTINUE'));

    expect(props.handleNavClick).toHaveBeenCalledWith(expect.anything(), '/check-income-tax/update-income/how-to-update-income/123');
  });

  test('Given no is selected, when continue is clicked, then the user is navigated back', () => {
    render(<InterruptionPage {...props} />);

    fireEvent.click(screen.getByLabelText('NO'));
    fireEvent.click(screen.getByText('CONTINUE'));

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  test('Given the backlink is clicked, when selected, then the user is navigated back', () => {
    render(<InterruptionPage {...props} />);

    fireEvent.click(screen.getByText('Back'));

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  test('Given the guidance link is rendered, when displayed, then the child benefit guidance text is shown', () => {
    render(<InterruptionPage {...props} />);

    expect(screen.getByText('READ_THE_GUIDANCE_ON_HIGH_INCOME')).toBeInTheDocument();
  });
});
