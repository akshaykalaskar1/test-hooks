import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';

import CookiePage from './index';

// ---- Mocks ----

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (k: string) => k })
}));

jest.mock('../../../../components/AppComponents/AppHeader', () => ({
  __esModule: true,
  default: () => <div>AppHeader</div>
}));

jest.mock('../../../../components/AppComponents/AppFooter', () => ({
  __esModule: true,
  default: () => <div>AppFooter</div>
}));

jest.mock('../../../../components/AppComponents/LanguageToggle', () => ({
  __esModule: true,
  default: () => <div>LanguageToggle</div>
}));

jest.mock('../../../../components/BaseComponents/MainWrapper', () => ({
  __esModule: true,
  default: ({ title, children }: any) => (
    <div className='govuk-width-container'>
      <div data-test-id='MainWrapper-title'>{String(title)}</div>
      {children}
    </div>
  )
}));

const cookieTableMock = jest.fn();

jest.mock('./CookiePageTable', () => ({
  __esModule: true,
  default: ({ cookies, tableCaption }: any) => {
    cookieTableMock({ cookies, tableCaption });
    return (
      <div data-test-id='CookiePageTable'>
        COOKIE_TABLE — count:{Array.isArray(cookies) ? cookies.length : 'NA'} — caption:
        {tableCaption}
      </div>
    );
  }
}));

jest.mock(
  '../../../../data/cookies/genericCookies.json',
  () => [
    { name: 'cookie_a', purpose: 'test', expires: 'session', domain: 'example.com' },
    { name: 'cookie_b', purpose: 'test2', expires: '1 year', domain: 'example.com' }
  ],
  { virtual: true }
);

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
     __esModule: true, 
      default: jest.fn()
   }));

describe('CookiePage (BDD Style)', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('Given the user opens the Cookie page', () => {
    describe('When the Cookie page loads', () => {
      it('Then it shows header, footer, language toggle, title, heading, paragraphs, link and table', () => {
        render(<CookiePage />);

        expect(screen.getByText('AppHeader')).toBeInTheDocument();
        expect(screen.getByText('AppFooter')).toBeInTheDocument();
        expect(screen.getByText('LanguageToggle')).toBeInTheDocument();

        expect(screen.getByTestId('MainWrapper-title')).toHaveTextContent('COOKIES');

        expect(screen.getByRole('heading', { name: 'COOKIES', level: 1 })).toBeInTheDocument();

        expect(screen.getByText('COOKIES_PAGE_P1')).toBeInTheDocument();
        expect(screen.getByText('COOKIES_PAGE_P2')).toBeInTheDocument();
        expect(screen.getByText('ESSENTIAL_COOKIES_P1')).toBeInTheDocument();

        const link = screen.getByRole('link', { name: 'COOKIE_FIND_OUT_MORE' });
        expect(link).toBeInTheDocument();
        expect(link).toHaveAttribute('href', 'https://www.tax.service.gov.uk/help/cookie-details');

        expect(screen.getByTestId('CookiePageTable')).toBeInTheDocument();
      });

      it('Then it calls setPageTitle once on load', () => {
        render(<CookiePage />);
        const setPageTitleMock = setPageTitle as jest.Mock;
        expect(setPageTitleMock).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Given the Cookie table is present', () => {
    describe('When cookies are loaded from the JSON', () => {
      it('Then CookiePageTable receives the cookies and localized caption', () => {
        render(<CookiePage />);

        expect(cookieTableMock).toHaveBeenCalledTimes(1);
        const { cookies, tableCaption } = (cookieTableMock as jest.Mock).mock.calls[0][0];

        expect(Array.isArray(cookies)).toBe(true);
        expect(cookies).toHaveLength(2);
        expect(cookies[0]).toMatchObject({ name: 'cookie_a' });
        expect(cookies[1]).toMatchObject({ name: 'cookie_b' });

        expect(tableCaption).toBe('ESSENTIAL_COOKIES');
        expect(screen.getByTestId('CookiePageTable')).toHaveTextContent('count:2');
        expect(screen.getByTestId('CookiePageTable')).toHaveTextContent(
          'caption:ESSENTIAL_COOKIES'
        );
      });
    });
  });
});
