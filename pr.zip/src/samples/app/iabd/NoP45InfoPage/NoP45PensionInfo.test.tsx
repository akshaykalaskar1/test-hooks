import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import NoP45PensionInfo from './NoP45PensionInfo';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('../../../../components/helpers/hooks/HMRCExternalLinks', () => ({
  __esModule: true,
  default: () => ({
    referrerURL: '/paye-summary'
  })
}));

jest.mock('../../../../components/AppComponents/AppHeader', () => ({
  __esModule: true,
  default: () => <div data-test-id='app-header'>Header</div>
}));

jest.mock('../../../../components/AppComponents/AppFooter', () => ({
  __esModule: true,
  default: () => <div data-test-id='app-footer'>Footer</div>
}));

jest.mock('../../../../components/AppComponents/LanguageToggle', () => ({
  __esModule: true,
  default: () => <div data-test-id='language-toggle'>Language</div>
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

describe('NoP45PensionInfo', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    render(<NoP45PensionInfo />);

    expect(screen.getByText('MY_P45_DOES_NOT_HAVE_THE_INFORMATION')).toBeInTheDocument();

    expect(screen.getByText('RETURN_TO_PAYE_INCOME_TAX_SUMMARY')).toBeInTheDocument();

    expect(screen.getByText('YOU_CAN_CONTACT_YOUR_PENSION_TO_GET_AN_UPDATED')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the page title is set', () => {
    render(<NoP45PensionInfo />);

    expect(setPageTitle).toHaveBeenCalled();
  });

  test('Given the page is rendered, when loaded, then the header footer and language toggle are displayed', () => {
    render(<NoP45PensionInfo />);

    expect(screen.getByTestId('app-header')).toBeInTheDocument();
    expect(screen.getByTestId('app-footer')).toBeInTheDocument();
    expect(screen.getByTestId('language-toggle')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the return link uses the referrer URL', () => {
    render(<NoP45PensionInfo />);

    const link = screen.getByRole('link', {
      name: 'RETURN_TO_PAYE_INCOME_TAX_SUMMARY'
    });

    expect(link).toHaveAttribute('href', '/paye-summary');
  });

  test('Given the page is rendered, when loaded, then the pension specific guidance is displayed', () => {
    render(<NoP45PensionInfo />);

    expect(screen.getByText(content => content.includes('WE_NEED_CERTAIN_DETAILS_FROM_YOUR_P45_PENSION'))).toBeInTheDocument();
    expect(screen.getByText(content => content.includes('IF_YOU_HAVE_LOST_CONTACT_WITH_YOUR_PENSION'))).toBeInTheDocument();
    expect(screen.getByText(content => content.includes('WE_WILL_THEN_UPDATE_YOUR_PENSION_FOR_YOU'))).toBeInTheDocument();
  });
});
