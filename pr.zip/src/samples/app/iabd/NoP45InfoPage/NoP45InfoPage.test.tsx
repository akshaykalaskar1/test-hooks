import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import NoP45InfoPage from './NoP45InfoPage';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('../../../../components/helpers/hooks/HMRCExternalLinks', () => ({
  __esModule: true,
  default: () => ({
    referrerURL: '/paye-summary'
  })
}));

jest.mock('../../../../components/AppComponents/AppHeader', () => ({
  __esModule: true,
  default: () => <div data-test-id='app-header'>Header</div>
}));

jest.mock('../../../../components/AppComponents/AppFooter', () => ({
  __esModule: true,
  default: () => <div data-test-id='app-footer'>Footer</div>
}));

jest.mock('../../../../components/AppComponents/LanguageToggle', () => ({
  __esModule: true,
  default: () => <div data-test-id='language-toggle'>Language</div>
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

describe('NoP45InfoPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    render(<NoP45InfoPage />);

    expect(screen.getByText('MY_P45_DOES_NOT_HAVE_THE_INFORMATION')).toBeInTheDocument();

    expect(screen.getByText('RETURN_TO_PAYE_INCOME_TAX_SUMMARY')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the page title is set', () => {
    render(<NoP45InfoPage />);

    expect(setPageTitle).toHaveBeenCalled();
  });

  test('Given the page is rendered, when loaded, then the header footer and language toggle are displayed', () => {
    render(<NoP45InfoPage />);

    expect(screen.getByTestId('app-header')).toBeInTheDocument();
    expect(screen.getByTestId('app-footer')).toBeInTheDocument();
    expect(screen.getByTestId('language-toggle')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the return link uses the referrer URL', () => {
    render(<NoP45InfoPage />);

    const link = screen.getByRole('link', {
      name: 'RETURN_TO_PAYE_INCOME_TAX_SUMMARY'
    });

    expect(link).toHaveAttribute('href', '/paye-summary');
  });
});
