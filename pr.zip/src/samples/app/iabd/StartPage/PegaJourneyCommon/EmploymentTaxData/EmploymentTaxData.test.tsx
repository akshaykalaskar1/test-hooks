import EmploymentTaxData from './EmploymentTaxData';
import { fetchDataAndError } from '../../../../../../components/helpers/utils';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  fetchDataAndError: jest.fn()
}));

describe('EmploymentTaxData', () => {
  const mockSetEmploymentTaxData = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given customer data exists, when fetchEmploymentTaxData is called, then employment tax data is set', async () => {
    (fetchDataAndError as jest.Mock).mockResolvedValue({
      Customer: { id: '123' },
      MDTPURLVALUE: 'test-url'
    });

    const { fetchEmploymentTaxData } = EmploymentTaxData(mockSetEmploymentTaxData);

    await fetchEmploymentTaxData();

    expect(mockSetEmploymentTaxData).toHaveBeenCalledWith({
      Customer: { id: '123' },
      MDTPURLVALUE: 'test-url'
    });
  });

  test('Given customer data does not exist, when fetchEmploymentTaxData is called, then null is set', async () => {
    (fetchDataAndError as jest.Mock).mockResolvedValue({
      Customer: null,
      MDTPURLVALUE: 'test-url'
    });

    const { fetchEmploymentTaxData } = EmploymentTaxData(mockSetEmploymentTaxData);

    await fetchEmploymentTaxData();

    expect(mockSetEmploymentTaxData).toHaveBeenCalledWith(null);
  });

  test('Given an error occurs, when fetchEmploymentTaxData is called, then the error is logged', async () => {
    const error = new Error('Test error');

    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    (fetchDataAndError as jest.Mock).mockRejectedValue(error);

    const { fetchEmploymentTaxData } = EmploymentTaxData(mockSetEmploymentTaxData);

    await fetchEmploymentTaxData();

    expect(consoleSpy).toHaveBeenCalledWith(error);

    consoleSpy.mockRestore();
  });
});
