import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import AddEmpStartPage from './AddEmpStartPage';

const mockNavigate = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ children, onClick, variant }: any) => <button onClick={onClick}>{children || (variant === 'backlink' ? 'Back' : '')}</button>
}));

jest.mock('hmrc-gds-react-components', () => ({
  StartButton: ({ text, onClick }: any) => <button onClick={onClick}>{text}</button>
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: any) => Component
}));

jest.mock('../../../AppSelector/payeRoutes', () => ({
  ADD_MISSING_EMPLOYMENT: '/add-missing-employment',
  ALLOWED_REDIRECTION: {
    ADD_EMPLOYMENT: '/add-employment',
    SUMMARY: '/summary'
  }
}));

describe('AddEmpStartPage', () => {
  const defaultProps = {
    dynamicEmpPayPeriod: 30
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    expect(screen.getByText('TELL_US_ABOUT_A_MISSING_EMPLOYMENT')).toBeInTheDocument();

    expect(screen.getByText('BEFORE_YOU_START')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then page title is set', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    expect(setPageTitle).toHaveBeenCalled();
  });

  test('Given the back button is clicked, when selected, then the user is navigated to the summary page', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('Back'));

    expect(mockNavigate).toHaveBeenCalledWith('/summary');
  });

  test('Given start now is clicked, when selected, then the user is navigated to the add employment journey', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('START_NOW'));

    expect(mockNavigate).toHaveBeenCalledWith(
      '/add-missing-employment',
      expect.objectContaining({
        state: expect.objectContaining({
          caseType: 'HMRC-PAYE-Work-IABD-MissingEmp',
          redirectPath: '/add-employment'
        })
      })
    );
  });

  test('Given an employment pay period exists, when rendered, then the pay period is displayed', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    expect(screen.getByText(/30/)).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then the employment guidance details are displayed', () => {
    render(<AddEmpStartPage {...defaultProps} />);

    expect(screen.getByText('NAME_OF_YOUR_EMPLOYER')).toBeInTheDocument();

    expect(screen.getByText('DATE_YOU_STARTED')).toBeInTheDocument();

    expect(screen.getByText('DATE_YOU_RECEIVED_YOUR_FIRST_PAYMENT')).toBeInTheDocument();

    expect(screen.getByText('EMPLOYERS_PAYE_REFERENCE')).toBeInTheDocument();

    expect(screen.getByText('PAYROLL_NUMBER_IF_YOU_KNOW_IT')).toBeInTheDocument();
  });
});
