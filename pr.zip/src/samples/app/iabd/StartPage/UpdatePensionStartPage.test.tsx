import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { useOutletContext } from 'react-router-dom';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import UpdatePensionStartPage from './UpdatePensionStartPage';

const mockNavigate = jest.fn();
const mockFetchEmploymentTaxData = jest.fn();
const mockSetEmploymentTaxData = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
  useLocation: () => ({
    pathname: '/update-pension'
  }),
  useOutletContext: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('./PegaJourneyCommon/EmploymentTaxData/EmploymentTaxData', () => ({
  __esModule: true,
  default: () => ({
    fetchEmploymentTaxData: mockFetchEmploymentTaxData
  })
}));

jest.mock('../../../../components/helpers/utils', () => ({
  filterList: jest.fn(list => list),
  getCurrentLang: jest.fn(() => 'en')
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ children, onClick, variant }: any) => <button onClick={onClick}>{children || (variant === 'backlink' ? 'Back' : '')}</button>
}));

jest.mock('hmrc-gds-react-components', () => ({
  StartButton: ({ text, onClick }: any) => <button onClick={onClick}>{text}</button>
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: any) => Component
}));

jest.mock('../../../AppSelector/payeRoutes', () => ({
  START_PEN_UPDATE: '/start-pension-update',
  ALLOWED_REDIRECTION: {
    UPDATE_PENSION: '/update-pension',
    SUMMARY: '/summary'
  }
}));

const mockUseOutletContext = useOutletContext as jest.Mock;

describe('UpdatePensionStartPage', () => {
  const defaultProps = {
    onStart: jest.fn(),
    pensionPeriod: 30
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    expect(screen.getByText('TELL_US_IF_A_PENSION_HAS_ENDED')).toBeInTheDocument();

    expect(screen.getByText('BEFORE_YOU_START')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then page title is set', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    expect(setPageTitle).toHaveBeenCalled();
  });

  test('Given pension data does not exist, when loaded, then employment tax data is fetched', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    expect(mockFetchEmploymentTaxData).toHaveBeenCalled();
  });

  test('Given pension data exists, when loaded, then employment tax data is not fetched', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: {
        Customer: {}
      },
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    expect(mockFetchEmploymentTaxData).not.toHaveBeenCalled();
  });

  test('Given the back button is clicked, when selected, then the user is navigated to summary page', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('Back'));

    expect(mockNavigate).toHaveBeenCalledWith('/summary');
  });

  test('Given start now is clicked, when selected, then the user is navigated to the pension pega journey', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('START_NOW'));

    expect(mockNavigate).toHaveBeenCalledWith(
      '/start-pension-update',
      expect.objectContaining({
        state: expect.objectContaining({
          caseType: 'HMRC-PAYE-Work-IABD-RemovePension'
        })
      })
    );
  });

  test('Given pension period exists, when rendered, then the pension period is displayed', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    expect(screen.getByText(/30/)).toBeInTheDocument();
  });

  test('Given current pension data exists, when start now is clicked, then current pension list is included in starting fields', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: {
        Customer: {
          TaxSummaryList: [
            {
              CurrentPensionList: [{ Name: 'Pension 1' }]
            }
          ]
        }
      },
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdatePensionStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('START_NOW'));

    expect(mockNavigate).toHaveBeenCalledWith(
      '/start-pension-update',
      expect.objectContaining({
        state: expect.objectContaining({
          startingFields: expect.objectContaining({
            NotificationLanguage: 'en',
            CurrentPensionList: [{ Name: 'Pension 1' }]
          })
        })
      })
    );
  });
});
