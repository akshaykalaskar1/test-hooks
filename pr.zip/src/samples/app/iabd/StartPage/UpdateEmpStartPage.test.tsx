import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { useOutletContext } from 'react-router-dom';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import UpdateEmpStartPage from './UpdateEmpStartPage';

const mockNavigate = jest.fn();
const mockFetchEmploymentTaxData = jest.fn();
const mockSetEmploymentTaxData = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
  useLocation: () => ({
    pathname: '/update-employment'
  }),
  useOutletContext: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../components/helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('./PegaJourneyCommon/EmploymentTaxData/EmploymentTaxData', () => ({
  __esModule: true,
  default: () => ({
    fetchEmploymentTaxData: mockFetchEmploymentTaxData
  })
}));

jest.mock('../../../../components/helpers/utils', () => ({
  filterList: jest.fn(list => list),
  getCurrentLang: jest.fn(() => 'en')
}));

jest.mock('../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ children, onClick, variant }: any) => <button onClick={onClick}>{children || (variant === 'backlink' ? 'Back' : '')}</button>
}));

jest.mock('hmrc-gds-react-components', () => ({
  StartButton: ({ text, onClick }: any) => <button onClick={onClick}>{text}</button>
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: any) => Component
}));

jest.mock('../../../AppSelector/payeRoutes', () => ({
  START_EMP_UPDATE: '/start-employment-update',
  ALLOWED_REDIRECTION: {
    UPDATE_EMPLOYMENT: '/update-employment',
    SUMMARY: '/summary'
  }
}));

const mockUseOutletContext = useOutletContext as jest.Mock;

describe('UpdateEmpStartPage', () => {
  const defaultProps = {
    onStart: jest.fn(),
    EmploymentPeriod: 30
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Given the page is rendered, when loaded, then the page content is displayed', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    expect(screen.getByText('TELL_US_IF_AN_EMPLOYMENT_HAS_ENDED')).toBeInTheDocument();

    expect(screen.getByText('BEFORE_YOU_START')).toBeInTheDocument();
  });

  test('Given the page is rendered, when loaded, then page title is set', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    expect(setPageTitle).toHaveBeenCalled();
  });

  test('Given employment tax data does not exist, when loaded, then employment tax data is fetched', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    expect(mockFetchEmploymentTaxData).toHaveBeenCalled();
  });

  test('Given employment tax data exists, when loaded, then employment tax data is not fetched', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: {
        Customer: {}
      },
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    expect(mockFetchEmploymentTaxData).not.toHaveBeenCalled();
  });

  test('Given the back button is clicked, when selected, then the user is navigated to summary page', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('Back'));

    expect(mockNavigate).toHaveBeenCalledWith('/summary');
  });

  test('Given start now is clicked, when selected, then the user is navigated to pega journey', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('START_NOW'));

    expect(mockNavigate).toHaveBeenCalledWith(
      '/start-employment-update',
      expect.objectContaining({
        state: expect.objectContaining({
          caseType: 'HMRC-PAYE-Work-IABD-UpdateEmpLeavingDate'
        })
      })
    );
  });

  test('Given employment period exists, when rendered, then the employment period is displayed', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: null,
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    expect(screen.getByText(/30/)).toBeInTheDocument();
  });

  test('Given current employment data exists, when start now is clicked, then current employment list is included in starting fields', () => {
    mockUseOutletContext.mockReturnValue({
      employmentTaxData: {
        Customer: {
          TaxSummaryList: [
            {
              CurrentEmploymentList: [{ Name: 'Employment 1' }]
            }
          ]
        }
      },
      setEmploymentTaxData: mockSetEmploymentTaxData
    });

    render(<UpdateEmpStartPage {...defaultProps} />);

    fireEvent.click(screen.getByText('START_NOW'));

    expect(mockNavigate).toHaveBeenCalledWith(
      '/start-employment-update',
      expect.objectContaining({
        state: expect.objectContaining({
          startingFields: expect.objectContaining({
            NotificationLanguage: 'en',
            CurrentEmploymentList: [{ Name: 'Employment 1' }]
          })
        })
      })
    );
  });
});
