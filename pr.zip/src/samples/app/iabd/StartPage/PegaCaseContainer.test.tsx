import { render, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';

import PegaCaseContainer from './PegaCaseContainer';
import useCustomNavigate from '../../../../components/helpers/hooks/useCustomNavigate';

const mockGoTo = jest.fn();
const mockShowPegaView = jest.fn();
const mockResetAppDisplay = jest.fn();
const mockSubscribe = jest.fn();
const mockUnsubscribe = jest.fn();
const mockCreateCase = jest.fn();
const mockCloseContainerItem = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('../../../../components/helpers/hooks/useCustomNavigate', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useLocation: () => ({
    state: {
      startingFields: {
        test: 'value'
      }
    }
  })
}));

describe('PegaCaseContainer', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    (useCustomNavigate as jest.Mock).mockReturnValue(mockGoTo);

    (globalThis as any).PCore = {
      getPubSubUtils: () => ({
        subscribe: mockSubscribe,
        unsubscribe: mockUnsubscribe
      }),
      getMashupApi: () => ({
        createCase: mockCreateCase
      }),
      getConstants: () => ({
        APP: {
          APP: 'APP'
        }
      }),
      getContainerUtils: () => ({
        getActiveContainerItemName: jest.fn().mockReturnValue('container'),
        getActiveContainerItemContext: jest.fn().mockReturnValue('context'),
        closeContainerItem: mockCloseContainerItem
      })
    };
  });

  test('Given the component mounts, when rendered, then the back event subscription is registered', () => {
    render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage={false}
      />
    );

    expect(mockSubscribe).toHaveBeenCalledWith('CUSTOM_EVENT_BACK', expect.any(Function));
  });

  test('Given the component unmounts, when cleanup runs, then the back event subscription is removed', () => {
    const { unmount } = render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage={false}
      />
    );

    unmount();

    expect(mockUnsubscribe).toHaveBeenCalledWith('CUSTOM_EVENT_BACK', 'handler');
  });

  test('Given resolution page is not shown, when rendered, then the case is created and pega view is displayed', async () => {
    mockCreateCase.mockResolvedValue({});

    render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage={false}
      />
    );

    await waitFor(() => {
      expect(mockCreateCase).toHaveBeenCalledWith('TestCase', 'APP', {
        startingFields: {
          test: 'value'
        }
      });
    });

    expect(mockShowPegaView).toHaveBeenCalled();
  });

  test('Given create case fails, when rendered, then the error is logged', async () => {
    const error = new Error('create case failed');

    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    mockCreateCase.mockRejectedValue(error);

    render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage={false}
      />
    );

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalledWith('Error at start of case: ', error);
    });

    consoleSpy.mockRestore();
  });

  test('Given resolution page is shown, when rendered, then create case is not called', () => {
    render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage
      />
    );

    expect(mockCreateCase).not.toHaveBeenCalled();
  });

  test('Given a back event is triggered, when the handler executes, then navigation reset and container close are performed', () => {
    render(
      <PegaCaseContainer
        caseType='TestCase'
        redirectPath='/summary'
        showPegaView={mockShowPegaView}
        resetAppDisplay={mockResetAppDisplay}
        getShutteredService={jest.fn()}
        showResolutionPage={false}
      />
    );

    const handler = mockSubscribe.mock.calls[0][1];

    handler();

    expect(mockGoTo).toHaveBeenCalledWith('/summary');
    expect(mockResetAppDisplay).toHaveBeenCalled();
    expect(mockCloseContainerItem).toHaveBeenCalled();
  });
});
