const PAYE_ROUTES = {
  ALLOWED_REDIRECTION: {
    LANDING: '/paye',
    SUMMARY: '/paye/summary',
    OTHER_INCOME_ALLOWANCES: '/paye/summary/other-income-allowances-benefits-deductions',
    ADD_EMPLOYMENT: '/paye/summary/add-employment',
    ADD_PENSION: '/paye/summary/add-pension',
    UPDATE_EMPLOYMENT: '/paye/summary/end-employment',
    UPDATE_PENSION: '/paye/summary/end-pension',
    SIGNOUT: '/paye/signout'
  },

  ALLOWED_PARAMETERISED_ROUTES: {
    P2_TAX_CODE_CHANGE: '/paye/summary/tax-code-change'
  },

  ADD_MISSING_EMPLOYMENT: '/paye/summary/add-missing-employment',
  START_EMP_UPDATE: '/paye/summary/employment-has-ended',
  START_PENSION: '/paye/summary/add-missing-pension',
  START_PEN_UPDATE: '/paye/summary/pension-has-ended',
  SUBMISSION_SUMMARY_START_EMP: '/paye/summary/add-missing-employment/status',
  SUBMISSION_SUMMARY_START_EMP_UPDATE: '/paye/summary/employment-has-ended/status',
  SUBMISSION_SUMMARY_START_PENSION: '/paye/summary/add-missing-pension/status',
  SUBMISSION_SUMMARY_START_PEN_UPDATE: '/paye/summary/pension-has-ended/status',

  RESTRICTED_REDIRECTION: {
    LATEST_EVENTS: '/paye/summary/account-activity',
    VIEW_ALL_DETAILS: '/paye/summary/all-details',
    VIEW_TIMELINE_DETAILS: '/paye/summary/account-activity-details',
    P2_EXPLAINER: '/paye/summary/tax-code-notice',
    DETAIL_EXPLAINER: '/paye/summary/understand-your-tax-details',
    UNDERSTAND_YOUR_TAX: '/paye/summary/understand-your-tax',
    UNDERSTAND_YOUR_TAX_SPECIAL: '/paye/summary/tax-code-details',
    ANNUAL_CODING: '/paye/summary/annual-coding',
    WINTER_FUEL_PAYMENT: '/paye/summary/winter-fuel-payment',
    UNTAXED_SAVINGS_INTEREST: '/paye/summary/untaxed-savings-interest',
    ABOUT_UNTAXED_SAVINGS_INTEREST: '/paye/summary/about-untaxed-savings-interest',
    WINTER_FUEL_PAYMENT_CHARGE: '/paye/summary/winter-fuel-payment-charge',
    INTERRUPTION: '/paye/interruption',
    UPDATE_ESTIMATED_TAXABLE_INCOME: '/paye/summary/update-estimated-taxable-income',
    VIEW_ALL_DETAILS_UPDATE_ESTIMATED_TAXABLE_INCOME: '/paye/summary/all-details/update-estimated-taxable-income',
    CANNOT_ACCESS_ACCOUNT: '/paye/cannot-access-account'
  },

  ERROR: '/paye/error',
  NO_INFORMATION: '/paye/no-information',
  NO_PENSION_INFO: '/paye/no-pension-info',
  SHUTTER: '/paye/service-unavailable',
  ACCESSIBILITY: 'paye/accessibility',
  COOKIES: 'paye/cookies'
} as const;

export default PAYE_ROUTES;
