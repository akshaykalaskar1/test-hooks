import {
  InterruptionRoute,
  UpdateEstimatedTaxableIncomeRoute,
  UntaxedSavingsInterestRoute,
  AboutUntaxedSavingsInterestRoute
} from './payeRoutesWrapper';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('./withIabdRoute', () => ({
  __esModule: true,
  default: jest.fn((Component, mapper) => ({
    Component,
    mapper
  }))
}));

interface RouteWithMapper {
  mapper: (props: any) => any;
}

describe('InterruptionRoute', () => {
  test('Given employment sequence number exists, when mapper is called, then interruption page props are returned', () => {
    const outlet = {
      goBack: jest.fn(),
      navClickHandler: jest.fn()
    };

    const state = {
      employmentSequenceNumber: 123
    };

    const result = (InterruptionRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state
    });

    expect(result).toEqual({
      pageName: 'Update estimated pay',
      onBack: outlet.goBack,
      employmentSequenceNumber: 123,
      handleNavClick: outlet.navClickHandler
    });
  });

  test('Given employment sequence number is undefined, when mapper is called, then null employment sequence number is returned', () => {
    const outlet = {
      goBack: jest.fn(),
      navClickHandler: jest.fn()
    };

    const result = (InterruptionRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state: {}
    });

    expect(result.employmentSequenceNumber).toBeNull();
  });
});

describe('UpdateEstimatedTaxableIncomeRoute', () => {
  test('Given update estimated taxable income state exists, when mapper is called, then update taxable income props are returned', () => {
    const outlet = {
      navClickHandler: jest.fn()
    };

    const state = {
      employerName: 'ABC Ltd',
      estimatedPay: 25000,
      tesUrl: 'test-url'
    };

    const result = (UpdateEstimatedTaxableIncomeRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state
    });

    expect(result).toEqual({
      pageName: 'Update estimated taxable income',
      employerName: 'ABC Ltd',
      estimatedPay: 25000,
      tesUrl: 'test-url',
      handleNavClick: outlet.navClickHandler
    });
  });

  test('Given state values are not available, when mapper is called, then undefined values are returned', () => {
    const outlet = {
      navClickHandler: jest.fn()
    };

    const result = (UpdateEstimatedTaxableIncomeRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state: {}
    });

    expect(result).toEqual({
      pageName: 'Update estimated taxable income',
      employerName: undefined,
      estimatedPay: undefined,
      tesUrl: undefined,
      handleNavClick: outlet.navClickHandler
    });
  });
});

describe('UntaxedSavingsInterestRoute', () => {
  test('Given untaxed savings interest values exist, when mapper is called, then route props are returned', () => {
    const outlet = {
      redirectToUnderstandYourTaxPage: jest.fn(),
      redirectToViewTimelineDetailsPage: jest.fn(),
      dynamicIABDVals: {
        CurrentTaxYear: '2025-26',
        SavingsInterestThreshold: 10000,
        StartingRateForSavings: 5000,
        NextTaxStartYear: '2026'
      }
    };

    const state = {
      comingFromPage: 'summary',
      GenericUntaxedSavingsInterest: true
    };

    const result = (UntaxedSavingsInterestRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state
    });

    expect(result).toEqual({
      redirectToUnderstandYourTaxPage: outlet.redirectToUnderstandYourTaxPage,
      redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
      comingFromPage: 'summary',
      CurrentTaxYear: '2025-26',
      savingsInterestThreshold: 10000,
      startingRateForSavings: 5000,
      NextTaxStartYear: '2026',
      genericUntaxedSavingsInterest: true
    });
  });

  test('Given no coming from page exists, when mapper is called, then empty string is returned', () => {
    const result = (UntaxedSavingsInterestRoute as unknown as RouteWithMapper).mapper({
      outlet: {
        redirectToUnderstandYourTaxPage: jest.fn(),
        redirectToViewTimelineDetailsPage: jest.fn(),
        dynamicIABDVals: {}
      },
      state: {}
    });

    expect(result.comingFromPage).toBe('');
  });

  test('Given dynamic values are not available, when mapper is called, then undefined values are returned', () => {
    const result = (UntaxedSavingsInterestRoute as unknown as RouteWithMapper).mapper({
      outlet: {
        redirectToUnderstandYourTaxPage: jest.fn(),
        redirectToViewTimelineDetailsPage: jest.fn()
      },
      state: {}
    });

    expect(result.CurrentTaxYear).toBeUndefined();
    expect(result.savingsInterestThreshold).toBeUndefined();
    expect(result.startingRateForSavings).toBeUndefined();
    expect(result.NextTaxStartYear).toBeUndefined();
    expect(result.genericUntaxedSavingsInterest).toBeUndefined();
  });
});

describe('AboutUntaxedSavingsInterestRoute', () => {
  test('Given route state exists, when mapper is called, then about untaxed savings interest props are returned', () => {
    const outlet = {
      redirectToUnderstandYourTaxPage: jest.fn(),
      redirectToViewTimelineDetailsPage: jest.fn()
    };

    const state = {
      pageName: 'Custom Page',
      comingFromPage: 'details'
    };

    const result = (AboutUntaxedSavingsInterestRoute as unknown as RouteWithMapper).mapper({
      outlet,
      state
    });

    expect(result).toEqual({
      pageName: 'Custom Page',
      redirectToUnderstandYourTaxPage: outlet.redirectToUnderstandYourTaxPage,
      redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
      comingFromPage: 'details'
    });
  });

  test('Given page name is not provided, when mapper is called, then default page name is returned', () => {
    const result = (AboutUntaxedSavingsInterestRoute as unknown as RouteWithMapper).mapper({
      outlet: {
        redirectToUnderstandYourTaxPage: jest.fn(),
        redirectToViewTimelineDetailsPage: jest.fn()
      },
      state: {}
    });

    expect(result.pageName).toBe('Untaxed savings interest');
    expect(result.comingFromPage).toBe('');
  });
});
